<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/../config/db.php';

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim(filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL));
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = 'Email and password are required.';
    } else {

        $stmt = $conn->prepare('SELECT id, full_name, email, password, role FROM users WHERE email = ? LIMIT 1');
        $stmt->bind_param('s', $email);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {

            $_SESSION['user'] = [
                'id'    => (int) $user['id'],
                'name'  => $user['full_name'],
                'email' => $user['email'],
                'role'  => strtolower($user['role']),
            ];

            $redirect = match ($_SESSION['user']['role']) {
                'admin' => '../dashboard/admin/index.php',
                default => '../dashboard/user/index.php',
            };

            header("Location: $redirect");
            exit;
        }

        $error = 'Invalid email or password.';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Nomuk Summer Camp Login</title>

    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #0f172a, #1e293b);
        }

        .login-container {
            width: 340px;
            padding: 35px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 15px 30px rgba(0,0,0,0.3);
            text-align: center;
            animation: fadeIn .4s ease-in-out;
        }

        .logo {
            width: 90px;
            height: 90px;
            object-fit: contain;
            margin-bottom: 10px;
        }

        h2 {
            margin: 10px 0 20px;
            font-size: 20px;
            color: #0f172a;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
        }

        input:focus {
            outline: none;
            border-color: #0f172a;
        }

        button {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            background: #0f172a;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background: #1e293b;
        }

        .error {
            color: #ef4444;
            font-size: 14px;
            margin-bottom: 10px;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>

<body>

<div class="login-container">

    <img src="../assets/logo.jpg" class="logo" alt="Logo">

    <h2>Nomuk Summer Camp</h2>

    <?php if ($error): ?>
        <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" autocomplete="off">
        <input type="email" name="email" placeholder="Email Address" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
    </form>

</div>

</body>
</html>