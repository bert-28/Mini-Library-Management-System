<?php

session_start();

// clear session properly
$_SESSION = [];
session_unset();
session_destroy();

// redirect to login (same folder)
header("Location: login.php");
exit();