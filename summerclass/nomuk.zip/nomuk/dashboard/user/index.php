<?php

/* =========================
   SESSION + AUTH CHECK
========================= */
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: /nomuk/auth/login.php");
    exit();
}

$user = $_SESSION['user'];
$name = $user['full_name'] ?? $user['name'] ?? 'User';

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Nomuk Camp Hub - User Dashboard</title>

<style>

/* =========================
   GLOBAL RESET
========================= */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial;
}

body {
    display: flex;
    min-height: 100vh;
    background: #f4f6f9;
    overflow-x: hidden;
}

/* =========================
   BACKGROUND EFFECT
========================= */
body::before,
body::after {
    content: "";
    position: fixed;
    width: 400px;
    height: 400px;
    border-radius: 50%;
    filter: blur(120px);
    z-index: -1;
    opacity: 0.25;
}

body::before {
    background: #38bdf8;
    top: -120px;
    left: -120px;
}

body::after {
    background: #6366f1;
    bottom: -120px;
    right: -120px;
}

/* =========================
   SIDEBAR
========================= */
.sidebar {
    width: 250px;
    background: #0f172a;
    color: #fff;
    padding: 20px;
    position: sticky;
    top: 0;
    height: 100vh;
}

/* BRAND */
.brand {
    text-align: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #1e293b;
}

.brand-logo {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    object-fit: cover;
    margin-bottom: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.25);
}

.brand h2 {
    font-size: 16px;
}

.brand p {
    font-size: 12px;
    color: #94a3b8;
}

/* LINKS */
.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    margin: 5px 0;
    border-radius: 6px;
    transition: 0.2s;
}

.sidebar a:hover {
    background: #1e293b;
}

.sidebar a.active {
    background: #1e293b;
    border-left: 4px solid #38bdf8;
}

.logout {
    color: #f87171;
}

/* =========================
   MAIN CONTENT
========================= */
.main {
    flex: 1;
    padding: 25px;
    animation: fadeIn 0.5s ease;
}

/* =========================
   TOP BAR
========================= */
.topbar {
    background: #fff;
    padding: 20px;
    border-radius: 14px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.06);
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    animation: slideDown 0.4s ease;
}

.welcome-section {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 55px;
    height: 55px;
    border-radius: 12px;
    object-fit: cover;
    box-shadow: 0 2px 10px rgba(0,0,0,0.15);
}

.welcome-text h2 {
    font-size: 20px;
    color: #0f172a;
}

.welcome-text p {
    font-size: 13px;
    color: #6b7280;
    margin-top: 4px;
}

.badge {
    background: #0f172a;
    color: #fff;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
}

/* =========================
   DESCRIPTION
========================= */
.desc {
    color: #6b7280;
    margin-bottom: 15px;
}

/* =========================
   STATS
========================= */
.stats {
    display: flex;
    gap: 10px;
    margin-bottom: 15px;
    flex-wrap: wrap;
}

.stat {
    background: #fff;
    padding: 12px 15px;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.05);
    font-size: 13px;
    color: #0f172a;
    transition: 0.2s;
}

.stat:hover {
    transform: translateY(-3px);
}

/* =========================
   CARDS GRID
========================= */
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 15px;
}

/* CARD */
.card {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    transition: 0.3s ease;
    animation: fadeUp 0.5s ease;
}

.card:hover {
    transform: translateY(-6px) scale(1.01);
    box-shadow: 0 15px 30px rgba(0,0,0,0.12);
}

.card h3 {
    margin-bottom: 10px;
    color: #0f172a;
}

.card p {
    color: #6b7280;
    font-size: 13px;
}

/* =========================
   BUTTON
========================= */
.btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 14px;
    background: #0f172a;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    transition: 0.2s;
}

.btn:hover {
    background: #1e293b;
}

/* =========================
   ANIMATIONS
========================= */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes slideDown {
    from { transform: translateY(-10px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

@keyframes fadeUp {
    from { transform: translateY(10px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

</style>

</head>

<body>

<!-- =========================
   SIDEBAR
========================= -->
<div class="sidebar">

    <div class="brand">
        <img src="/nomuk/assets/logo.jpg" class="brand-logo" alt="Logo">
        <h2>Nomuk Camp Hub</h2>
        <p>User Portal</p>
    </div>

    <a href="/nomuk/dashboard/user/index.php" class="active">🏠 Dashboard</a>
    <a href="/nomuk/dashboard/user/view_books.php">📖 View Books</a>
    <a href="/nomuk/dashboard/user/my_books.php">📌 My Borrowed Books</a>
    <a href="/nomuk/dashboard/user/profile.php">⚙️ Account Settings</a>
    <a href="/nomuk/auth/logout.php" class="logout">🚪 Logout</a>

</div>

<!-- =========================
   MAIN CONTENT
========================= -->
<div class="main">

    <!-- TOP BAR -->
    <div class="topbar">

        <div class="welcome-section">
            <img src="/nomuk/assets/logo.jpg" class="logo" alt="Logo">

            <div class="welcome-text">
                <h2>Welcome, <?= htmlspecialchars($name); ?> 👋</h2>
                <p>Nomuk Summer Camp Library Portal</p>
            </div>
        </div>

        <div class="badge">STUDENT</div>

    </div>

    <!-- DESCRIPTION -->
    <p class="desc">
        Browse books, borrow available copies, and manage your library activity in real time.
    </p>

    <!-- STATS -->
    <div class="stats">
        <div class="stat">📚 Library Access</div>
        <div class="stat">⏳ Borrow Limit: 3 Books</div>
        <div class="stat">📅 7-Day Return Policy</div>
    </div>

    <!-- CARDS -->
    <div class="cards">

        <div class="card">
            <h3>📖 Available Books</h3>
            <p>Browse all books and borrow available copies.</p>
            <a href="/nomuk/dashboard/user/view_books.php" class="btn">View Books</a>
        </div>

        <div class="card">
            <h3>📌 My Borrowed Books</h3>
            <p>Check your borrowed books and due dates.</p>
            <a href="/nomuk/dashboard/user/my_books.php" class="btn">My Books</a>
        </div>

        <div class="card">
            <h3>⚙️ Profile</h3>
            <p>Update your personal account information.</p>
            <a href="/nomuk/dashboard/user/profile.php" class="btn">Edit Profile</a>
        </div>

    </div>

</div>

</body>
</html>