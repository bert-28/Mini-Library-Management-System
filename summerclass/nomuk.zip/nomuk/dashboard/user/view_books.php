<?php
session_start();
include("../../config/db.php");

if (!isset($_SESSION['user'])) {
    header("Location: /nomuk/auth/login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];
$name = $_SESSION['user']['full_name'] ?? 'User';

/* BORROW LOGIC */
if (isset($_GET['borrow'])) {

    $book_id = (int) $_GET['borrow'];

    $check = $conn->prepare("
        SELECT COUNT(*) as total 
        FROM transactions 
        WHERE user_id = ? AND status = 'BORROWED'
    ");
    $check->bind_param("i", $user_id);
    $check->execute();
    $borrowed = $check->get_result()->fetch_assoc()['total'];

    if ($borrowed >= 3) {
        $error = "❌ Borrow limit reached (3 books max)";
    } else {

        $copyStmt = $conn->prepare("
            SELECT copy_id 
            FROM book_copies 
            WHERE book_id = ? AND status = 'AVAILABLE'
            LIMIT 1
        ");
        $copyStmt->bind_param("i", $book_id);
        $copyStmt->execute();
        $copy = $copyStmt->get_result()->fetch_assoc();

        if ($copy) {

            $copy_id = $copy['copy_id'];
            $due = date('Y-m-d H:i:s', strtotime('+7 days'));

            $insert = $conn->prepare("
                INSERT INTO transactions (user_id, copy_id, due_date, status)
                VALUES (?, ?, ?, 'BORROWED')
            ");
            $insert->bind_param("iis", $user_id, $copy_id, $due);
            $insert->execute();

            $update = $conn->prepare("
                UPDATE book_copies 
                SET status='BORROWED'
                WHERE copy_id=?
            ");
            $update->bind_param("i", $copy_id);
            $update->execute();

            $success = "📚 Book successfully borrowed!";
        } else {
            $error = "❌ No available copies right now.";
        }
    }
}

/* BOOKS */
$sql = "
SELECT 
    b.book_id,
    b.title,
    b.author,
    b.category,
    COUNT(CASE WHEN bc.status='AVAILABLE' THEN 1 END) AS available
FROM books b
LEFT JOIN book_copies bc ON b.book_id = bc.book_id
GROUP BY b.book_id
ORDER BY b.book_id DESC
";

$books = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>View Books</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Arial;
}

body{
    display:flex;
    min-height:100vh;
    background:#f4f6f9;
    overflow-x:hidden;
}

/* SOFT LIFE BACKGROUND */
body::before,
body::after{
    content:"";
    position:fixed;
    width:420px;
    height:420px;
    border-radius:50%;
    filter:blur(120px);
    z-index:-1;
    opacity:0.22;
    animation: floatGlow 10s infinite alternate ease-in-out;
}

body::before{
    background:#38bdf8;
    top:-120px;
    left:-120px;
}

body::after{
    background:#6366f1;
    bottom:-140px;
    right:-140px;
}

/* SIDEBAR (UNCHANGED) */
.sidebar{
    width:250px;
    background:#0f172a;
    color:white;
    padding:20px;
    position:sticky;
    top:0;
    height:100vh;
}

.brand{
    text-align:center;
    margin-bottom:20px;
    padding-bottom:15px;
    border-bottom:1px solid #1e293b;
}

.brand-logo{
    width:60px;
    height:60px;
    border-radius:12px;
    object-fit:cover;
    margin-bottom:10px;
}

.brand h2{ font-size:16px; }
.brand p{ font-size:12px; color:#94a3b8; }

.sidebar a{
    display:block;
    color:white;
    text-decoration:none;
    padding:10px;
    margin:5px 0;
    border-radius:6px;
}

.sidebar a:hover{ background:#1e293b; }

/* MAIN */
.main{
    flex:1;
    padding:25px;
    animation:fadeIn 0.5s ease;
}

/* TOP BAR */
.topbar{
    background:white;
    padding:20px;
    border-radius:14px;
    box-shadow:0 10px 30px rgba(0,0,0,0.06);
    margin-bottom:20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    animation: slideDown 0.5s ease;
}

.welcome-section{
    display:flex;
    align-items:center;
    gap:15px;
}

.logo{
    width:55px;
    height:55px;
    border-radius:12px;
    object-fit:cover;
}

/* BADGE */
.badge{
    background:#0f172a;
    color:white;
    padding:6px 14px;
    border-radius:20px;
    font-size:12px;
}

/* BACK BUTTON (IMPROVED BUT SAME STYLE) */
.back-btn{
    display:inline-flex;
    align-items:center;
    gap:6px;
    margin-bottom:15px;
    padding:8px 14px;
    background:#0f172a;
    color:white;
    text-decoration:none;
    border-radius:8px;
    font-size:13px;
    transition:0.2s ease;
}

.back-btn:hover{
    background:#1e293b;
    transform:translateY(-2px);
}

/* STATS */
.stats{
    display:flex;
    gap:10px;
    margin-bottom:15px;
}

.stat{
    background:white;
    padding:12px 15px;
    border-radius:10px;
    box-shadow:0 2px 10px rgba(0,0,0,0.05);
    font-size:13px;
    transition:0.2s;
}

.stat:hover{
    transform:translateY(-3px);
}

/* ALERT */
.alert{
    padding:12px;
    border-radius:8px;
    margin-bottom:15px;
    animation: pop 0.3s ease;
}

.success{ background:#dcfce7; color:#166534; }
.error{ background:#fee2e2; color:#991b1b; }

/* GRID */
.grid{
    display:grid;
    grid-template-columns:repeat(auto-fit, minmax(240px, 1fr));
    gap:15px;
}

/* CARD (LIFE) */
.card{
    background:white;
    padding:20px;
    border-radius:14px;
    box-shadow:0 2px 10px rgba(0,0,0,0.06);
    transition:0.25s ease;
    animation: fadeUp 0.5s ease;
}

.card:hover{
    transform:translateY(-8px);
    box-shadow:0 15px 30px rgba(0,0,0,0.12);
}

.card h3{
    margin-bottom:8px;
    color:#0f172a;
}

.card p{
    color:#6b7280;
    font-size:13px;
}

/* BUTTON */
.btn{
    display:inline-block;
    margin-top:10px;
    padding:10px 14px;
    background:#0f172a;
    color:white;
    text-decoration:none;
    border-radius:8px;
    transition:0.2s;
}

.btn:hover{
    background:#1e293b;
    transform:scale(1.05);
}

.disabled{
    background:#9ca3af;
    pointer-events:none;
}

/* ANIMATIONS */
@keyframes fadeIn{ from{opacity:0;} to{opacity:1;} }
@keyframes slideDown{ from{transform:translateY(-10px);opacity:0;} to{transform:translateY(0);opacity:1;} }
@keyframes fadeUp{ from{transform:translateY(10px);opacity:0;} to{transform:translateY(0);opacity:1;} }
@keyframes pop{ from{transform:scale(0.95);opacity:0;} to{transform:scale(1);opacity:1;} }

@keyframes floatGlow{
    from{transform:translateY(0px);}
    to{transform:translateY(20px);}
}
</style>
</head>

<body>

<div class="sidebar">
    <div class="brand">
        <img src="/nomuk/assets/logo.jpg" class="brand-logo">
        <h2>Nomuk Camp Hub</h2>
        <p>User Portal</p>
    </div>

    <a href="/nomuk/dashboard/user/index.php">🏠 Dashboard</a>
    <a class="active" href="/nomuk/dashboard/user/view_books.php">📖 View Books</a>
    <a href="/nomuk/dashboard/user/my_books.php">📌 My Borrowed Books</a>
    <a href="/nomuk/dashboard/user/profile.php">⚙️ Account Settings</a>
    <a href="/nomuk/auth/logout.php">🚪 Logout</a>
</div>

<div class="main">

<!-- BACK BUTTON -->
<a href="/nomuk/dashboard/user/index.php" class="back-btn">⬅ Back to Dashboard</a>

<div class="topbar">
    <div class="welcome-section">
        <img src="/nomuk/assets/logo.jpg" class="logo">
        <div>
            <h2>📚 Library Catalog</h2>
            <p style="color:#6b7280;font-size:13px;">Borrow up to 3 books</p>
        </div>
    </div>

    <div class="badge">STUDENT</div>
</div>

<div class="stats">
    <div class="stat">📖 Browse & Borrow</div>
    <div class="stat">⏳ Limit: 3 Books</div>
    <div class="stat">📅 7 Days Due</div>
</div>

<?php if (isset($success)): ?>
<div class="alert success"><?= $success ?></div>
<?php endif; ?>

<?php if (isset($error)): ?>
<div class="alert error"><?= $error ?></div>
<?php endif; ?>

<div class="grid">

<?php while($b = $books->fetch_assoc()): ?>
<div class="card">
    <h3><?= htmlspecialchars($b['title']) ?></h3>
    <p>
        Author: <?= htmlspecialchars($b['author']) ?><br>
        Category: <?= htmlspecialchars($b['category']) ?>
    </p>

    <?php if ($b['available'] > 0): ?>
        <p style="margin-top:8px;color:#16a34a;">Available: <?= $b['available'] ?></p>
        <a class="btn" href="?borrow=<?= $b['book_id'] ?>">Borrow</a>
    <?php else: ?>
        <p style="margin-top:8px;color:#ef4444;">Not Available</p>
        <span class="btn disabled">Unavailable</span>
    <?php endif; ?>
</div>
<?php endwhile; ?>

</div>

</div>

</body>
</html>