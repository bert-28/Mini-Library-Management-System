<?php

/* =========================
   SESSION + DB CONNECTION
========================= */
session_start();
include("../../config/db.php");

/* =========================
   AUTH CHECK
========================= */
if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

$user_id = $_SESSION['user']['id'];

/* =========================
   RETURN BOOK ACTION
========================= */
if (isset($_GET['return'])) {

    $transaction_id = (int) $_GET['return'];

    $get = $conn->prepare("
        SELECT copy_id
        FROM transactions
        WHERE transaction_id = ?
        AND user_id = ?
    ");

    $get->bind_param("ii", $transaction_id, $user_id);
    $get->execute();

    $res = $get->get_result()->fetch_assoc();

    if ($res) {

        $copy_id = $res['copy_id'];

        // mark transaction as returned
        $conn->query("
            UPDATE transactions
            SET status = 'RETURNED',
                return_date = NOW()
            WHERE transaction_id = $transaction_id
        ");

        // restore book copy
        $conn->query("
            UPDATE book_copies
            SET status = 'AVAILABLE'
            WHERE copy_id = $copy_id
        ");

        $success = "📚 Book returned successfully!";

    } else {
        $error = "❌ Invalid return request.";
    }
}

/* =========================
   FETCH USER BOOKS
========================= */
$sql = "
    SELECT 
        t.transaction_id,
        b.title,
        t.borrow_date,
        t.due_date,
        t.status
    FROM transactions t
    JOIN book_copies bc ON t.copy_id = bc.copy_id
    JOIN books b ON bc.book_id = b.book_id
    WHERE t.user_id = ?
    ORDER BY t.borrow_date DESC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();

$result = $stmt->get_result();

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>My Books</title>

<style>

/* =========================
   GLOBAL RESET
========================= */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial;
}

body {
    display: flex;
    min-height: 100vh;
    background: #f4f6f9;
    overflow-x: hidden;
}

/* =========================
   BACKGROUND EFFECT
========================= */
body::before,
body::after {
    content: "";
    position: fixed;
    width: 420px;
    height: 420px;
    border-radius: 50%;
    filter: blur(120px);
    z-index: -1;
    opacity: 0.22;
    animation: floatGlow 10s infinite alternate ease-in-out;
}

body::before {
    background: #38bdf8;
    top: -120px;
    left: -120px;
}

body::after {
    background: #6366f1;
    bottom: -140px;
    right: -140px;
}

/* =========================
   SIDEBAR
========================= */
.sidebar {
    width: 250px;
    background: #0f172a;
    color: #fff;
    padding: 20px;
    position: sticky;
    top: 0;
    height: 100vh;
}

/* BRAND */
.brand {
    text-align: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 1px solid #1e293b;
}

.brand-logo {
    width: 60px;
    height: 60px;
    border-radius: 12px;
    object-fit: cover;
    margin-bottom: 10px;
}

.brand h2 { font-size: 16px; }
.brand p { font-size: 12px; color: #94a3b8; }

/* LINKS */
.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    margin: 5px 0;
    border-radius: 6px;
}

.sidebar a:hover {
    background: #1e293b;
}

/* =========================
   MAIN CONTENT
========================= */
.main {
    flex: 1;
    padding: 25px;
    animation: fadeIn 0.5s ease;
}

/* =========================
   TOP BAR
========================= */
.topbar {
    background: #fff;
    padding: 20px;
    border-radius: 14px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.06);
    margin-bottom: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    animation: slideDown 0.5s ease;
}

.welcome-section {
    display: flex;
    align-items: center;
    gap: 15px;
}

.logo {
    width: 55px;
    height: 55px;
    border-radius: 12px;
    object-fit: cover;
}

.badge {
    background: #0f172a;
    color: #fff;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 12px;
}

/* =========================
   BACK BUTTON
========================= */
.back-btn {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 15px;
    padding: 8px 14px;
    background: #0f172a;
    color: #fff;
    text-decoration: none;
    border-radius: 8px;
    font-size: 13px;
}

.back-btn:hover {
    background: #1e293b;
    transform: translateY(-2px);
}

/* =========================
   ALERTS
========================= */
.alert {
    padding: 12px;
    border-radius: 8px;
    margin-bottom: 15px;
}

.success {
    background: #dcfce7;
    color: #166534;
}

.error {
    background: #fee2e2;
    color: #991b1b;
}

/* =========================
   CARD
========================= */
.card {
    background: #fff;
    padding: 20px;
    border-radius: 14px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
}

/* =========================
   TABLE
========================= */
table {
    width: 100%;
    border-collapse: collapse;
}

th {
    background: #0f172a;
    color: #fff;
    padding: 12px;
    text-align: left;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #f1f5f9;
}

/* =========================
   STATUS BADGES
========================= */
.status {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    color: #fff;
}

.BORROWED { background: #f59e0b; }
.RETURNED { background: #10b981; }
.OVERDUE { background: #ef4444; }

/* =========================
   BUTTON
========================= */
.btn {
    padding: 8px 12px;
    background: #0f172a;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    font-size: 12px;
}

.btn:hover {
    background: #1e293b;
}

/* =========================
   ANIMATIONS
========================= */
@keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes slideDown { from { transform: translateY(-10px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
@keyframes floatGlow { from { transform: translateY(0); } to { transform: translateY(20px); } }

</style>

</head>

<body>

<!-- =========================
   SIDEBAR
========================= -->
<div class="sidebar">

    <div class="brand">
        <img src="/nomuk/assets/logo.jpg" class="brand-logo">
        <h2>Nomuk Camp Hub</h2>
        <p>User Portal</p>
    </div>

    <a href="/nomuk/dashboard/user/index.php">🏠 Dashboard</a>
    <a href="/nomuk/dashboard/user/view_books.php">📖 View Books</a>
    <a class="active" href="/nomuk/dashboard/user/my_books.php">📌 My Borrowed Books</a>
    <a href="/nomuk/dashboard/user/profile.php">⚙️ Account Settings</a>
    <a href="/nomuk/auth/logout.php">🚪 Logout</a>

</div>

<!-- =========================
   MAIN CONTENT
========================= -->
<div class="main">

    <a href="/nomuk/dashboard/user/index.php" class="back-btn">⬅ Back to Dashboard</a>

    <div class="topbar">
        <div class="welcome-section">
            <img src="/nomuk/assets/logo.jpg" class="logo">
            <div>
                <h2>📌 My Borrowed Books</h2>
                <p style="color:#6b7280;font-size:13px;">Track and return your borrowed books</p>
            </div>
        </div>

        <div class="badge">STUDENT</div>
    </div>

    <!-- ALERTS -->
    <?php if (isset($success)): ?>
        <div class="alert success"><?= $success ?></div>
    <?php endif; ?>

    <?php if (isset($error)): ?>
        <div class="alert error"><?= $error ?></div>
    <?php endif; ?>

    <!-- TABLE -->
    <div class="card">

        <?php if ($result->num_rows > 0): ?>

        <table>
            <tr>
                <th>Title</th>
                <th>Borrow Date</th>
                <th>Due Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>

            <?php while ($row = $result->fetch_assoc()): ?>

            <?php
            $status = strtoupper($row['status']);
            if ($status == "BORROWED" && time() > strtotime($row['due_date'])) {
                $status = "OVERDUE";
            }
            ?>

            <tr>
                <td><?= htmlspecialchars($row['title']) ?></td>
                <td><?= $row['borrow_date'] ?></td>
                <td><?= $row['due_date'] ?></td>
                <td><span class="status <?= $status ?>"><?= $status ?></span></td>
                <td>
                    <?php if ($row['status'] == "BORROWED"): ?>
                        <a class="btn" href="?return=<?= $row['transaction_id'] ?>">Return</a>
                    <?php else: ?>
                        —
                    <?php endif; ?>
                </td>
            </tr>

            <?php endwhile; ?>

        </table>

        <?php else: ?>

        <p style="text-align:center;color:#6b7280;padding:30px;">
            📚 No borrowed books yet
        </p>

        <?php endif; ?>

    </div>

</div>

</body>
</html>