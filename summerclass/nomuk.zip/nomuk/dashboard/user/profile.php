<?php

/* =========================
   SESSION + AUTH CHECK
========================= */
session_start();
include("../../config/db.php");

if (!isset($_SESSION['user'])) {
    header("Location: ../auth/login.php");
    exit();
}

/* =========================
   FETCH USER DATA
========================= */
$user_id = $_SESSION['user']['id'];

$stmt = $conn->prepare("
    SELECT full_name, email, role, created_at 
    FROM users 
    WHERE id = ?
");

$stmt->bind_param("i", $user_id);
$stmt->execute();

$user = $stmt->get_result()->fetch_assoc();

?>

<!-- =========================
     HTML OUTPUT
========================= -->
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>My Profile</title>
</head>

<body>

    <!-- =========================
         PROFILE SECTION
    ========================= -->
    <h2>⚙️ My Profile</h2>

    <p><b>Name:</b> <?= $user['full_name'] ?></p>
    <p><b>Email:</b> <?= $user['email'] ?></p>
    <p><b>Role:</b> <?= $user['role'] ?></p>
    <p><b>Joined:</b> <?= $user['created_at'] ?></p>

</body>
</html>