<?php

/* =========================
   SESSION + AUTH CHECK
========================= */
session_start();
include("../../config/db.php");

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: /nomuk/auth/login.php");
    exit();
}

/* =========================
   ADD BOOK
========================= */
if (isset($_POST['add'])) {

    $stmt = $conn->prepare("
        INSERT INTO books (title, author, category)
        VALUES (?, ?, ?)
    ");

    $stmt->bind_param(
        "sss",
        $_POST['title'],
        $_POST['author'],
        $_POST['category']
    );

    $stmt->execute();

    // create initial copy (AVAILABLE)
    $book_id = $conn->insert_id;

    $copy = $conn->prepare("
        INSERT INTO book_copies (book_id, status)
        VALUES (?, 'AVAILABLE')
    ");

    $copy->bind_param("i", $book_id);
    $copy->execute();
}

/* =========================
   DELETE BOOK
========================= */
if (isset($_GET['delete'])) {

    $stmt = $conn->prepare("
        DELETE FROM books
        WHERE book_id = ?
    ");

    $stmt->bind_param("i", $_GET['delete']);
    $stmt->execute();

    header("Location: books.php");
    exit();
}

/* =========================
   FETCH DATA
========================= */
$books = $conn->query("
    SELECT * 
    FROM books 
    ORDER BY book_id DESC
");

$totalBooks = $conn->query("
    SELECT COUNT(*) AS total 
    FROM books
")->fetch_assoc()['total'];

?>

<!-- =========================
     HTML START
========================= -->
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Books</title>

<style>

    /* =========================
    GLOBAL LAYOUT
    ========================= */
    body {
        margin: 0;
        font-family: Arial;
        display: flex;
        background: #f4f6f9;
    }

    /* =========================
    SIDEBAR
    ========================= */
    .sidebar {
        width: 250px;
        background: #0f172a;
        color: #fff;
        padding: 20px;
        height: 100vh;
        position: sticky;
        top: 0;
    }

    .sidebar h2 {
        margin-bottom: 20px;
    }

    .sidebar a {
        display: block;
        color: #fff;
        text-decoration: none;
        padding: 10px;
        margin: 5px 0;
        border-radius: 6px;
        transition: 0.2s;
    }

    .sidebar a:hover {
        background: #1e293b;
    }

    /* =========================
    MAIN CONTENT
    ========================= */
    .main {
        flex: 1;
        padding: 25px;
        animation: fadeIn 0.3s ease;
    }

    /* HEADER */
    .header h2 {
        margin: 0;
        color: #0f172a;
    }

    .header p {
        margin-top: 5px;
        color: #6b7280;
    }

    /* BACK BUTTON */
    .back {
        display: inline-block;
        margin-bottom: 15px;
        background: #6b7280;
        color: #fff;
        padding: 8px 12px;
        text-decoration: none;
        border-radius: 6px;
    }

    .back:hover {
        background: #4b5563;
    }

    /* =========================
    CARDS
    ========================= */
    .card {
        background: #fff;
        padding: 20px;
        border-radius: 12px;
        margin-bottom: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    }

    /* =========================
    STATS
    ========================= */
    .stat {
        background: #0f172a;
        color: #fff;
        padding: 10px 15px;
        border-radius: 10px;
        display: inline-block;
    }

    /* =========================
    FORM ELEMENTS
    ========================= */
    input {
        padding: 10px;
        margin: 5px;
        border: 1px solid #ddd;
        border-radius: 6px;
    }

    input:focus {
        border-color: #0f172a;
        outline: none;
    }

    /* =========================
    BUTTONS
    ========================= */
    .btn {
        padding: 10px 14px;
        background: #0f172a;
        color: #fff;
        border: none;
        border-radius: 6px;
        cursor: pointer;
    }

    .btn:hover {
        background: #1e293b;
    }

    .btn-danger {
        background: #ef4444;
    }

    .btn-danger:hover {
        background: #dc2626;
    }

    /* =========================
    TABLE
    ========================= */
    table {
        width: 100%;
        border-collapse: collapse;
    }

    th {
        background: #0f172a;
        color: #fff;
        padding: 12px;
        text-align: left;
    }

    td {
        padding: 12px;
        border-bottom: 1px solid #eee;
    }

    tr:hover {
        background: #f1f5f9;
    }

    /* =========================
    ANIMATION
    ========================= */
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(5px); }
        to { opacity: 1; transform: translateY(0); }
    }

</style>

</head>

    <body>

        <!-- =========================
            SIDEBAR
        ========================= -->
        <div class="sidebar">
            <h2>⚙️ Admin Panel</h2>

            <a href="index.php">🏠 Dashboard</a>
            <a href="books.php">📚 Manage Books</a>
            <a href="users.php">👤 Manage Users</a>
            <a href="transactions.php">📊 Manage Transactions</a>
            <a href="/nomuk/auth/logout.php">🚪 Logout</a>
        </div>

        <!-- =========================
            MAIN CONTENT
        ========================= -->
        <div class="main">

            <!-- HEADER -->
            <div class="header">
                <h2>📚 Books Management</h2>
                <p>Manage library collection</p>
            </div>

            <a class="back" href="index.php">⬅ Back to Dashboard</a>

            <!-- OVERVIEW -->
            <div class="card">
                <h3>📊 Overview</h3>
                <div class="stat">Total Books: <?= $totalBooks ?></div>
            </div>

            <!-- ADD BOOK -->
            <div class="card">
                <h3>➕ Add New Book</h3>

                <form method="POST">
                    <input name="title" placeholder="Book Title" required>
                    <input name="author" placeholder="Author" required>
                    <input name="category" placeholder="Category" required>
                    <button class="btn" name="add">Add Book</button>
                </form>
            </div>

            <!-- BOOK LIST -->
            <div class="card">
                <h3>📖 Book List</h3>

                <table>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Category</th>
                        <th>Action</th>
                    </tr>

                    <?php while ($b = $books->fetch_assoc()): ?>
                    <tr>
                        <td><?= $b['book_id'] ?></td>
                        <td><?= htmlspecialchars($b['title']) ?></td>
                        <td><?= htmlspecialchars($b['author']) ?></td>
                        <td><?= htmlspecialchars($b['category']) ?></td>
                        <td>
                            <a class="btn btn-danger"
                            href="?delete=<?= $b['book_id'] ?>"
                            onclick="return confirm('Delete this book?')">
                            Delete
                            </a>
                        </td>
                    </tr>
                    <?php endwhile; ?>

                </table>
            </div>

        </div>

    </body>
</html>