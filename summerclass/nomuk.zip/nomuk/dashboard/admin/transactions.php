<?php

/* =========================
   SESSION + DB CONNECTION
========================= */
session_start();
include("../../config/db.php");

/* =========================
   SECURITY CHECK (ADMIN ONLY)
========================= */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: /nomuk/auth/login.php");
    exit();
}

/* =========================
   AUTO OVERDUE UPDATE
========================= */
$conn->query("
    UPDATE transactions
    SET status = 'OVERDUE'
    WHERE status = 'BORROWED'
    AND due_date < NOW()
");

/* =========================
   FETCH TRANSACTIONS DATA
========================= */
$sql = "
    SELECT t.*, u.full_name, b.title
    FROM transactions t
    JOIN users u ON t.user_id = u.id
    JOIN book_copies c ON t.copy_id = c.copy_id
    JOIN books b ON c.book_id = b.book_id
    ORDER BY t.borrow_date DESC
";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Transactions</title>

<style>

/* =========================
   GLOBAL LAYOUT
========================= */
body {
    margin: 0;
    font-family: Arial;
    display: flex;
    background: #f4f6f9;
    overflow-x: hidden;
}

/* =========================
   BACKGROUND EFFECT
========================= */
body::before,
body::after {
    content: "";
    position: fixed;
    width: 420px;
    height: 420px;
    border-radius: 50%;
    filter: blur(120px);
    z-index: -1;
    opacity: 0.22;
}

body::before {
    background: #38bdf8;
    top: -120px;
    left: -120px;
    animation: float 8s infinite alternate;
}

body::after {
    background: #6366f1;
    bottom: -120px;
    right: -120px;
    animation: float 10s infinite alternate;
}

@keyframes float {
    from { transform: translateY(0); }
    to { transform: translateY(20px); }
}

/* =========================
   SIDEBAR
========================= */
.sidebar {
    width: 250px;
    background: #0f172a;
    color: #fff;
    padding: 20px;
    height: 100vh;
    position: sticky;
    top: 0;
}

.sidebar h2 {
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    margin: 5px 0;
    border-radius: 6px;
    transition: 0.2s;
}

.sidebar a:hover {
    background: #1e293b;
}

/* =========================
   MAIN CONTENT
========================= */
.main {
    flex: 1;
    padding: 25px;
    animation: fadeIn 0.4s ease;
}

/* HEADER */
.header h2 {
    margin: 0;
    color: #0f172a;
}

.header p {
    margin-top: 5px;
    color: #6b7280;
}

/* BACK BUTTON */
.back {
    display: inline-block;
    margin-bottom: 15px;
    background: #6b7280;
    color: #fff;
    padding: 8px 12px;
    text-decoration: none;
    border-radius: 6px;
    transition: 0.2s;
}

.back:hover {
    background: #4b5563;
}

/* =========================
   CARD
========================= */
.card {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    transition: 0.25s;
    animation: fadeUp 0.5s ease;
}

.card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
}

/* =========================
   TABLE
========================= */
table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 8px;
    overflow: hidden;
}

th {
    background: #0f172a;
    color: #fff;
    padding: 12px;
    text-align: left;
    font-size: 13px;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    font-size: 13px;
    transition: 0.2s;
}

tr:hover {
    background: #f1f5f9;
    transform: scale(1.01);
}

/* =========================
   STATUS BADGES
========================= */
.status {
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
    color: #fff;
    display: inline-block;
    animation: pop 0.3s ease;
}

.borrowed {
    background: #f59e0b;
}

.returned {
    background: #10b981;
}

.overdue {
    background: #ef4444;
    animation: pulse 1.5s infinite;
}

/* =========================
   ANIMATIONS
========================= */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

@keyframes fadeUp {
    from { transform: translateY(10px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
}

@keyframes pop {
    from { transform: scale(0.9); opacity: 0; }
    to { transform: scale(1); opacity: 1; }
}

@keyframes pulse {
    0% { opacity: 1; }
    50% { opacity: 0.5; }
    100% { opacity: 1; }
}

</style>

</head>

<body>

<!-- =========================
   SIDEBAR
========================= -->
<div class="sidebar">
    <h2>⚙️ Admin Panel</h2>

    <a href="index.php">🏠 Dashboard</a>
    <a href="books.php">📚 Manage Books</a>
    <a href="users.php">👤 Manage Users</a>
    <a href="transactions.php">📊 Manage Transactions</a>
    <a href="/nomuk/auth/logout.php">🚪 Logout</a>
</div>

<!-- =========================
   MAIN CONTENT
========================= -->
<div class="main">

    <!-- HEADER -->
    <div class="header">
        <h2>📊 Transactions</h2>
        <p>Track borrowing, returns, and overdue books</p>
    </div>

    <a class="back" href="index.php">⬅ Back to Dashboard</a>

    <!-- TABLE CARD -->
    <div class="card">

        <table>
            <tr>
                <th>User</th>
                <th>Book</th>
                <th>Borrow Date</th>
                <th>Due Date</th>
                <th>Status</th>
            </tr>

            <?php while ($t = $result->fetch_assoc()): ?>

            <?php $status = strtolower($t['status']); ?>

            <tr>
                <td><?= htmlspecialchars($t['full_name']) ?></td>
                <td><?= htmlspecialchars($t['title']) ?></td>
                <td><?= $t['borrow_date'] ?></td>
                <td><?= $t['due_date'] ?></td>
                <td>
                    <span class="status <?= $status ?>">
                        <?= ucfirst($status) ?>
                    </span>
                </td>
            </tr>

            <?php endwhile; ?>

        </table>

    </div>

</div>

</body>
</html>