<?php

/* =========================
   SESSION + AUTH CHECK
========================= */
session_start();
include("../../config/db.php");

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: /nomuk/auth/login.php");
    exit();
}

/* =========================
   GET USER ID
========================= */
$id = $_GET['id'] ?? null;

if (!$id) {
    header("Location: users.php");
    exit();
}

/* =========================
   FETCH USER DATA
========================= */
$user = $conn->query("
    SELECT * 
    FROM users 
    WHERE id = $id
")->fetch_assoc();

if (!$user) {
    echo "User not found";
    exit();
}

/* =========================
   UPDATE USER
========================= */
if (isset($_POST['update'])) {

    $stmt = $conn->prepare("
        UPDATE users 
        SET full_name = ?, email = ?, role = ?
        WHERE id = ?
    ");

    $stmt->bind_param(
        "sssi",
        $_POST['full_name'],
        $_POST['email'],
        $_POST['role'],
        $id
    );

    $stmt->execute();

    header("Location: users.php");
    exit();
}

?>

<!-- =========================
     HTML START
========================= -->
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Edit User</title>

<style>

/* =========================
   GLOBAL LAYOUT
========================= */
body {
    margin: 0;
    font-family: Arial;
    display: flex;
    background: #f4f6f9;
}

/* =========================
   SIDEBAR
========================= */
.sidebar {
    width: 250px;
    background: #0f172a;
    color: #fff;
    padding: 20px;
    height: 100vh;
    position: sticky;
    top: 0;
}

.sidebar h2 {
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    margin: 5px 0;
    border-radius: 6px;
    transition: 0.2s;
}

.sidebar a:hover {
    background: #1e293b;
}

/* =========================
   MAIN CONTENT
========================= */
.main {
    flex: 1;
    padding: 30px;
    animation: fadeIn 0.3s ease;
}

/* HEADER */
.header h2 {
    margin: 0;
    color: #0f172a;
}

.header p {
    margin-top: 5px;
    color: #6b7280;
}

/* BACK BUTTON */
.back {
    display: inline-block;
    margin-bottom: 15px;
    background: #6b7280;
    color: #fff;
    padding: 8px 12px;
    text-decoration: none;
    border-radius: 6px;
}

.back:hover {
    background: #4b5563;
}

/* =========================
   CARD
========================= */
.card {
    background: #fff;
    padding: 25px;
    border-radius: 12px;
    max-width: 450px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
}

/* =========================
   FORM
========================= */
label {
    display: block;
    margin-top: 10px;
    font-weight: bold;
    color: #374151;
}

input,
select {
    width: 100%;
    padding: 10px;
    margin-top: 5px;
    border: 1px solid #ddd;
    border-radius: 6px;
}

input:focus,
select:focus {
    border-color: #0f172a;
    outline: none;
}

/* =========================
   BUTTON
========================= */
.btn {
    margin-top: 15px;
    padding: 10px 14px;
    width: 100%;
    background: #0f172a;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}

.btn:hover {
    background: #1e293b;
}

/* =========================
   ANIMATION
========================= */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(5px); }
    to { opacity: 1; transform: translateY(0); }
}

</style>

</head>

<body>

<!-- =========================
   SIDEBAR
========================= -->
<div class="sidebar">
    <h2>⚙️ Admin Panel</h2>

    <a href="index.php">🏠 Dashboard</a>
    <a href="books.php">📚 Manage Books</a>
    <a href="users.php">👤 Manage Users</a>
    <a href="transactions.php">📊 Manage Transactions</a>
    <a href="/nomuk/auth/logout.php">🚪 Logout</a>
</div>

<!-- =========================
   MAIN CONTENT
========================= -->
<div class="main">

    <!-- HEADER -->
    <div class="header">
        <h2>✏️ Edit User</h2>
        <p>Update user information safely</p>
    </div>

    <a class="back" href="users.php">⬅ Back to Users</a>

    <!-- FORM -->
    <div class="card">

        <form method="POST">

            <label>Full Name</label>
            <input type="text" name="full_name"
                   value="<?= htmlspecialchars($user['full_name']) ?>" required>

            <label>Email</label>
            <input type="email" name="email"
                   value="<?= htmlspecialchars($user['email']) ?>" required>

            <label>Role</label>
            <select name="role">
                <option value="student" <?= $user['role'] == 'student' ? 'selected' : '' ?>>
                    Student
                </option>
                <option value="admin" <?= $user['role'] == 'admin' ? 'selected' : '' ?>>
                    Admin
                </option>
            </select>

            <button class="btn" name="update">Update User</button>

        </form>

    </div>

</div>

</body>
</html>