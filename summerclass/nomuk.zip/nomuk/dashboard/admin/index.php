<?php

/* =========================
   SESSION + ADMIN CHECK
========================= */
session_start();

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: /nomuk/auth/login.php");
    exit();
}

$user = $_SESSION['user'];
$name = $user['name'] ?? $user['full_name'] ?? 'Admin';

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Admin Dashboard</title>

<style>

/* =========================
   GLOBAL LAYOUT
========================= */
body {
    margin: 0;
    font-family: Arial;
    display: flex;
    background: #f4f6f9;
}

/* =========================
   SIDEBAR
========================= */
.sidebar {
    width: 240px;
    background: #0f172a;
    color: #fff;
    padding: 20px;
    height: 100vh;
}

.sidebar h2 {
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    margin: 5px 0;
    border-radius: 6px;
    transition: 0.2s;
}

.sidebar a:hover {
    background: #1e293b;
}

/* =========================
   MAIN CONTENT
========================= */
.main {
    flex: 1;
    padding: 25px;
    animation: fadeIn 0.3s ease;
}

/* =========================
   TOP BAR
========================= */
.topbar {
    background: #fff;
    padding: 20px;
    border-radius: 14px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    margin-bottom: 25px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

/* WELCOME SECTION */
.welcome-section {
    display: flex;
    align-items: center;
    gap: 15px;
}

/* LOGO */
.logo {
    width: 55px;
    height: 55px;
    border-radius: 12px;
    object-fit: cover;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
}

/* TEXT */
.welcome-text h2 {
    margin: 0;
    font-size: 22px;
    color: #0f172a;
}

.welcome-text p {
    margin: 4px 0 0;
    font-size: 13px;
    color: #6b7280;
}

/* BADGE */
.badge {
    background: #0f172a;
    color: #fff;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
}

/* =========================
   CARDS GRID
========================= */
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 20px;
}

/* CARD */
.card {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
    transition: 0.2s;
}

.card:hover {
    transform: translateY(-3px);
}

.card h3 {
    margin-bottom: 10px;
    color: #0f172a;
}

/* BUTTON */
.btn {
    display: inline-block;
    margin-top: 10px;
    padding: 10px 14px;
    background: #0f172a;
    color: #fff;
    text-decoration: none;
    border-radius: 6px;
    transition: 0.2s;
}

.btn:hover {
    background: #1e293b;
}

/* =========================
   ANIMATION
========================= */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(5px); }
    to { opacity: 1; transform: translateY(0); }
}

</style>

</head>

<body>

<!-- =========================
   SIDEBAR
========================= -->
<div class="sidebar">
    <h2>⚙️ Admin Panel</h2>

    <a href="/nomuk/dashboard/admin/index.php">🏠 Dashboard</a>
    <a href="/nomuk/dashboard/admin/books.php">📚 Manage Books</a>
    <a href="/nomuk/dashboard/admin/users.php">👤 Manage Users</a>
    <a href="/nomuk/dashboard/admin/transactions.php">📊 Manage Transactions</a>
    <a href="/nomuk/auth/logout.php">🚪 Logout</a>
</div>

<!-- =========================
   MAIN CONTENT
========================= -->
<div class="main">

    <!-- TOP BAR -->
    <div class="topbar">

        <div class="welcome-section">

            <img src="/nomuk/assets/logo.jpg" class="logo" alt="Logo">

            <div class="welcome-text">
                <h2>Welcome back, <?= htmlspecialchars($name); ?> 👋</h2>
                <p>Nomuk Summer Camp Library Management System</p>
            </div>

        </div>

        <div class="badge">
            ADMIN ACCESS
        </div>

    </div>

    <!-- CARDS -->
    <div class="cards">

        <div class="card">
            <h3>📚 Books</h3>
            <p>Add, edit, and manage all library books.</p>
            <a href="/nomuk/dashboard/admin/books.php" class="btn">Open</a>
        </div>

        <div class="card">
            <h3>👤 Users</h3>
            <p>Manage students and admin accounts.</p>
            <a href="/nomuk/dashboard/admin/users.php" class="btn">Open</a>
        </div>

        <div class="card">
            <h3>📊 Transactions</h3>
            <p>Track borrow and return activity.</p>
            <a href="/nomuk/dashboard/admin/transactions.php" class="btn">Open</a>
        </div>

    </div>

</div>

</body>
</html>