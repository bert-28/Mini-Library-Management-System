<?php

/* =========================
   SESSION + DB CONNECTION
========================= */
session_start();
include("../../config/db.php");

/* =========================
   ADMIN AUTH CHECK
========================= */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: /nomuk/auth/login.php");
    exit();
}

/* =========================
   ADD USER
========================= */
if (isset($_POST['add_user'])) {

    $name     = $_POST['full_name'];
    $email    = $_POST['email'];
    $role     = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $stmt = $conn->prepare("
        INSERT INTO users (full_name, email, password, role)
        VALUES (?, ?, ?, ?)
    ");

    $stmt->bind_param(
        "ssss",
        $name,
        $email,
        $password,
        $role
    );

    $stmt->execute();
}

/* =========================
   DELETE USER
========================= */
if (isset($_GET['delete'])) {

    $stmt = $conn->prepare("
        DELETE FROM users
        WHERE id = ?
    ");

    $stmt->bind_param("i", $_GET['delete']);
    $stmt->execute();

    header("Location: users.php");
    exit();
}

/* =========================
   FETCH USERS DATA
========================= */
$users = $conn->query("
    SELECT *
    FROM users
    ORDER BY id DESC
");

$totalUsers = $conn->query("
    SELECT COUNT(*) AS total
    FROM users
")->fetch_assoc()['total'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<title>Users</title>

<style>

/* =========================
   GLOBAL LAYOUT
========================= */
body {
    margin: 0;
    font-family: Arial;
    display: flex;
    background: #f4f6f9;
}

/* =========================
   SIDEBAR
========================= */
.sidebar {
    width: 250px;
    background: #0f172a;
    color: #fff;
    padding: 20px;
    height: 100vh;
    position: sticky;
    top: 0;
}

.sidebar h2 {
    margin-bottom: 20px;
}

.sidebar a {
    display: block;
    color: #fff;
    text-decoration: none;
    padding: 10px;
    margin: 5px 0;
    border-radius: 6px;
    transition: 0.2s;
}

.sidebar a:hover {
    background: #1e293b;
}

/* =========================
   MAIN CONTENT
========================= */
.main {
    flex: 1;
    padding: 25px;
    animation: fadeIn 0.3s ease;
}

/* HEADER */
.header h2 {
    margin: 0;
    color: #0f172a;
}

.header p {
    margin-top: 5px;
    color: #6b7280;
}

/* BACK BUTTON */
.back {
    display: inline-block;
    margin-bottom: 15px;
    background: #6b7280;
    color: #fff;
    padding: 8px 12px;
    text-decoration: none;
    border-radius: 6px;
}

.back:hover {
    background: #4b5563;
}

/* =========================
   CARD SYSTEM
========================= */
.card {
    background: #fff;
    padding: 20px;
    border-radius: 12px;
    margin-bottom: 20px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.06);
}

.card:hover {
    transform: translateY(-2px);
}

/* =========================
   STATS
========================= */
.stat {
    background: #0f172a;
    color: #fff;
    padding: 10px 15px;
    border-radius: 10px;
}

/* =========================
   FORM ELEMENTS
========================= */
input,
select {
    padding: 10px;
    margin: 5px;
    border: 1px solid #ddd;
    border-radius: 6px;
}

input:focus,
select:focus {
    border-color: #0f172a;
    box-shadow: 0 0 5px rgba(15,23,42,0.2);
}

/* =========================
   BUTTONS
========================= */
.btn {
    padding: 10px 14px;
    background: #0f172a;
    color: #fff;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    transition: 0.2s;
}

.btn:hover {
    background: #1e293b;
}

.btn-danger {
    background: #ef4444;
}

.btn-danger:hover {
    background: #dc2626;
}

.btn-edit {
    background: #3b82f6;
}

.btn-edit:hover {
    background: #2563eb;
}

/* =========================
   TABLE
========================= */
table {
    width: 100%;
    border-collapse: collapse;
    border-radius: 8px;
    overflow: hidden;
}

th {
    background: #0f172a;
    color: #fff;
    padding: 12px;
    text-align: left;
}

td {
    padding: 12px;
    border-bottom: 1px solid #eee;
}

tr:hover {
    background: #f1f5f9;
}

/* =========================
   SEARCH BAR
========================= */
.search {
    width: 100%;
    padding: 10px;
    margin-bottom: 10px;
    border-radius: 8px;
    border: 1px solid #ddd;
}

/* =========================
   ANIMATION
========================= */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(5px); }
    to { opacity: 1; transform: translateY(0); }
}

</style>

</head>

<body>

<!-- =========================
   SIDEBAR
========================= -->
<div class="sidebar">
    <h2>⚙️ Admin Panel</h2>

    <a href="index.php">🏠 Dashboard</a>
    <a href="books.php">📚 Manage Books</a>
    <a href="users.php">👤 Manage Users</a>
    <a href="transactions.php">📊 Manage Transactions</a>
    <a href="/nomuk/auth/logout.php">🚪 Logout</a>
</div>

<!-- =========================
   MAIN CONTENT
========================= -->
<div class="main">

    <!-- HEADER -->
    <div class="header">
        <h2>👥 Users Management</h2>
        <p>Manage students and admin accounts</p>
    </div>

    <a class="back" href="index.php">⬅ Back to Dashboard</a>

    <!-- OVERVIEW -->
    <div class="card">
        <h3>📊 Overview</h3>
        <div class="stat">Total Users: <?= $totalUsers ?></div>
    </div>

    <!-- ADD USER -->
    <div class="card">
        <h3>➕ Add New User</h3>

        <form method="POST">
            <input type="text" name="full_name" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <select name="role">
                <option value="student">Student</option>
                <option value="admin">Admin</option>
            </select>

            <button class="btn" name="add_user">Add User</button>
        </form>
    </div>

    <!-- USER TABLE -->
    <div class="card">
        <h3>📋 User List</h3>

        <input class="search" type="text" id="search" placeholder="Search users...">

        <table id="table">
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Role</th>
                <th>Action</th>
            </tr>

            <?php while ($u = $users->fetch_assoc()): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= htmlspecialchars($u['full_name']) ?></td>
                <td><?= htmlspecialchars($u['email']) ?></td>
                <td><?= $u['role'] ?></td>
                <td>
                    <a class="btn btn-edit" href="edit_user.php?id=<?= $u['id'] ?>">Edit</a>

                    <a class="btn btn-danger"
                       href="?delete=<?= $u['id'] ?>"
                       onclick="return confirm('Delete this user?')">
                       Delete
                    </a>
                </td>
            </tr>
            <?php endwhile; ?>

        </table>
    </div>

</div>

<!-- =========================
   SEARCH SCRIPT
========================= -->
<script>
document.getElementById("search").addEventListener("keyup", function () {

    let filter = this.value.toLowerCase();
    let rows = document.querySelectorAll("#table tr");

    rows.forEach((row, index) => {

        if (index === 0) return;

        let text = row.innerText.toLowerCase();
        row.style.display = text.includes(filter) ? "" : "none";
    });
});
</script>

</body>
</html>