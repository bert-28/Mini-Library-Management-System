<?php

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "nomuk_library";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("DB Error: " . $conn->connect_error);
}

$conn->set_charset("utf8mb4");

/**
 * Optional helper function (useful later)
 */
function db()
{
    global $conn;
    return $conn;
}