<?php
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isAdmin() ? '/admin/dashboard.php' : '/user/dashboard.php'));
} else {
    header('Location: ' . BASE_URL . '/login.php');
}
exit;
