<?php
require_once __DIR__ . '/../includes/config.php';
requireStudent(); // Ensures only students can access this
require_once __DIR__ . '/../includes/layout.php';

$db = getDB();
$studentId = getStudentIdFromUserId(getCurrentUserId());

// 1. Get Student Personal Stats
$statsQuery = $db->prepare("
    SELECT 
        (SELECT COUNT(*) FROM borrow_records WHERE student_id = ? AND status IN ('borrowed', 'overdue')) as active_borrows,
        (SELECT IFNULL(SUM(fine_amount), 0) FROM fines WHERE student_id = ? AND is_paid = 0) as total_fines
");
$statsQuery->execute([$studentId, $studentId]);
$userStats = $statsQuery->fetch();

// 2. Get List of Books
$borrows = $db->prepare("
    SELECT br.*, b.book_name, b.book_author 
    FROM borrow_records br 
    JOIN books b ON br.book_id = b.book_id 
    WHERE br.student_id = ? AND br.status IN ('borrowed', 'overdue')
    ORDER BY br.due_date ASC
");
$borrows->execute([$studentId]);
$borrowList = $borrows->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard — Nomuk Library</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="app-layout">
        <?php renderStudentSidebar('dashboard'); ?> 
        
        <div class="main-content">
            <?php renderTopHeader('Student Dashboard'); ?>
            
            <div class="page-content" style="padding: 30px;">
                <div class="page-header" style="margin-bottom: 30px;">
                    <div class="page-title">
                        <h2 style="font-size: 24px; font-weight: 800; color: #1B2559;">Welcome back, <?= clean(getCurrentUsername()) ?>! 👋</h2>
                        <p style="color: #A3AED0; font-weight: 500;">Here's what's happening with your library account.</p>
                    </div>
                </div>

                <div class="stat-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 30px;">
                    
                    <div class="stat-card" style="background: white; padding: 25px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 20px;">
                        <div style="background: #E7E9FB; color: #4318FF; width: 56px; height: 56px; border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                            <?= icons('book') ?>
                        </div>
                        <div>
                            <span style="color: #A3AED0; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Active Borrows</span>
                            <strong style="display: block; font-size: 24px; color: #1B2559;"><?= $userStats['active_borrows'] ?> Books</strong>
                        </div>
                    </div>

                    <div class="stat-card" style="background: white; padding: 25px; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 20px;">
                        <div style="background: #FFF5F2; color: #FF5630; width: 56px; height: 56px; border-radius: 16px; display: flex; align-items: center; justify-content: center;">
                            <?= icons('fine') ?>
                        </div>
                        <div>
                            <span style="color: #A3AED0; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Total Fines</span>
                            <strong style="display: block; font-size: 24px; color: #FF5630;">₱<?= number_format($userStats['total_fines'], 2) ?></strong>
                        </div>
                    </div>

                </div>

                <div class="card" style="background: white; border-radius: 20px; padding: 25px; box-shadow: 0 10px 30px rgba(0,0,0,0.02); border: none;">
                    <div class="card-header" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center;">
                        <h3 style="font-size: 18px; font-weight: 800; color: #1B2559;">Currently Borrowed</h3>
                        <a href="<?= BASE_URL ?>/user/catalog.php" style="color: #4318FF; font-weight: 700; text-decoration: none; font-size: 14px;">Browse more books →</a>
                    </div>

                    <div class="table-wrapper">
                        <table class="data-table" style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="text-align: left; border-bottom: 1px solid #F4F7FE;">
                                    <th style="padding: 15px 10px; color: #A3AED0; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Book Details</th>
                                    <th style="padding: 15px 10px; color: #A3AED0; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Due Date</th>
                                    <th style="padding: 15px 10px; color: #A3AED0; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(empty($borrowList)): ?>
                                    <tr>
                                        <td colspan="3" style="padding: 50px; text-align: center; color: #A3AED0;">
                                            <div style="font-size: 40px; margin-bottom: 10px;">📚</div>
                                            <p>You don't have any borrowed books at the moment.</p>
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach($borrowList as $row): ?>
                                    <tr style="border-bottom: 1px solid #F4F7FE;">
                                        <td style="padding: 15px 10px;">
                                            <div style="font-weight: 700; color: #1B2559;"><?= clean($row['book_name']) ?></div>
                                            <div style="font-size: 13px; color: #A3AED0;"><?= clean($row['book_author']) ?></div>
                                        </td>
                                        <td style="padding: 15px 10px; font-weight: 600; color: #1B2559;">
                                            <?= date('M d, Y', strtotime($row['due_date'])) ?>
                                        </td>
                                        <td style="padding: 15px 10px;">
                                            <?php if($row['status'] == 'overdue'): ?>
                                                <span style="background: #FFF5F2; color: #FF5630; padding: 6px 12px; border-radius: 8px; font-size: 12px; font-weight: 700;">OVERDUE</span>
                                            <?php else: ?>
                                                <span style="background: #E2FFF3; color: #05CD99; padding: 6px 12px; border-radius: 8px; font-size: 12px; font-weight: 700;">ACTIVE</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div style="margin-top: 30px; background: #F4F7FE; padding: 20px; border-radius: 15px; border: 1px dashed #A3AED0; text-align: center;">
                    <p style="color: #707EAE; font-size: 13px; font-weight: 500;">
                        <strong>Friendly Reminder:</strong> Please return books on or before the due date. 
                        A fine of <strong>₱<?= number_format(FINE_PER_DAY, 2) ?></strong> is charged for every day a book is overdue.
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>