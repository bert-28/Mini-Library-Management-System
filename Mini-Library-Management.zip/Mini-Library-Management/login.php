<?php
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isAdmin() ? '/admin/dashboard.php' : '/user/dashboard.php'));
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');
    $password   = trim($_POST['password'] ?? '');

    if (!$identifier || !$password) {
        $error = 'Please fill in all fields.';
    } else {
        $db = getDB();
        $stmt = $db->prepare("SELECT * FROM users WHERE (username = ? OR email = ?) LIMIT 1");
        $stmt->execute([$identifier, $identifier]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password_hash'])) {
            loginUser($user);
            header('Location: ' . BASE_URL . ($user['role'] === 'admin' ? '/admin/dashboard.php' : '/user/dashboard.php'));
            exit;
        } else {
            $error = 'Invalid username/email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign In — Nomuk Library</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4318FF;
            --primary-hover: #3311CC;
            --text-main: #1B2559;
            --text-muted: #A3AED0;
            --bg-body: #F4F7FE;
            --white: #FFFFFF;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }

        body {
            background-color: var(--bg-body);
            display: flex;
            min-height: 100vh;
            color: var(--text-main);
        }

        /* Split Layout */
        .auth-container {
            display: flex;
            width: 100%;
        }

        /* Left Side: Brand Hero */
        .auth-hero {
            flex: 1.2;
            background: linear-gradient(135deg, #4318ff 0%, #b099ff 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            padding: 40px;
            position: relative;
            overflow: hidden;
        }

        /* Visual Element: Large Circle Background */
        .auth-hero::before {
            content: "";
            position: absolute;
            width: 600px;
            height: 600px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
            top: -100px;
            left: -100px;
        }

        .hero-content { position: relative; text-align: center; z-index: 1; }
        .hero-content h1 { font-size: 3.5rem; font-weight: 800; letter-spacing: -2px; margin-bottom: 10px; }
        .hero-content p { font-size: 1.1rem; opacity: 0.9; font-weight: 500; }

        /* Right Side: Form Area */
        .auth-form-side {
            flex: 1;
            background: var(--bg-body);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
        }

        .auth-card {
            width: 100%;
            max-width: 420px;
            background: white;
            padding: 40px;
            border-radius: 30px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.04);
        }

        .auth-header { margin-bottom: 30px; }
        .auth-header h2 { font-size: 1.8rem; font-weight: 800; margin-bottom: 8px; }
        .auth-header p { color: var(--text-muted); font-size: 0.95rem; }

        .form-group { margin-bottom: 20px; }
        .form-label { display: block; font-size: 14px; font-weight: 700; margin-bottom: 10px; color: var(--text-main); }
        
        .form-input {
            width: 100%;
            padding: 15px 20px;
            border-radius: 16px;
            border: 2px solid #E0E5F2;
            outline: none;
            font-size: 15px;
            transition: 0.3s;
        }

        .form-input:focus { border-color: var(--primary); }

        .btn-signin {
            width: 100%;
            background: var(--primary);
            color: white;
            padding: 16px;
            border-radius: 16px;
            border: none;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 10px 20px rgba(67, 24, 255, 0.2);
            transition: 0.3s;
            margin-top: 10px;
        }

        .btn-signin:hover { background: var(--primary-hover); transform: translateY(-2px); }

        .flash-error {
            background: #FFF5F5;
            color: #E53E3E;
            padding: 12px;
            border-radius: 12px;
            font-size: 14px;
            margin-bottom: 20px;
            font-weight: 600;
            text-align: center;
        }

        .demo-box {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #F4F7FE;
        }

        @media (max-width: 900px) {
            .auth-hero { display: none; }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-hero">
            <div class="hero-content">
                <h1>NOMUK</h1>
                <p>Summer Class Library Management System</p>
            </div>
        </div>

        <div class="auth-form-side">
            <div class="auth-card">
                <div class="auth-header">
                    <h2>Sign In</h2>
                    <p>Enter your details to access the system</p>
                </div>

                <?php if ($error): ?>
                    <div class="flash-error">✕ <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>

                <form method="POST">
                    <div class="form-group">
                        <label class="form-label">Username or Email</label>
                        <input type="text" name="identifier" class="form-input" 
                               placeholder="username" 
                               value="<?= htmlspecialchars($_POST['identifier'] ?? '') ?>" required autofocus>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-input" 
                               placeholder="password" required>
                    </div>
                    
                    <button type="submit" class="btn-signin">Sign In</button>
                </form>

                <p style="text-align: center; margin-top: 25px; font-size: 14px; color: var(--text-muted);">
                    Don't have an account? <a href="register.php" style="color: var(--primary); font-weight: 700; text-decoration: none;">Create one</a>
                </p>

                <div class="demo-box">
                    <p style="font-size: 11px; font-weight: 800; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px; text-align: center; margin-bottom: 15px;">Demo Access</p>
                    <div style="display: flex; gap: 10px;">
                        <div style="flex: 1; background: #F4F7FE; padding: 12px; border-radius: 12px; font-size: 12px;">
                            <strong style="color: var(--primary);">Admin</strong><br>
                            <code>admin / password</code>
                        </div>
                        <div style="flex: 1; background: #F4F7FE; padding: 12px; border-radius: 12px; font-size: 12px;">
                            <strong style="color: var(--primary);">Student</strong><br>
                            Create via register
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>