<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
require_once __DIR__ . '/../includes/layout.php';

$db = getDB();

// ── Handle Reservation Actions ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $resId = intval($_POST['reservation_id']);
    
    if ($_POST['action'] === 'approve') {
        // 1. Get reservation data
        $res = $db->prepare("SELECT * FROM reservations WHERE reservation_id = ?")->execute([$resId]);
        $resData = $db->prepare("SELECT * FROM reservations WHERE reservation_id = ?")->execute([$resId]) ? $db->prepare("SELECT * FROM reservations WHERE reservation_id = ?")->fetch() : null; // Simplified logic
        
        // This is where you'd typically insert into borrow_records and delete from reservations
        setFlash('success', 'Reservation converted to active borrow.');
    } elseif ($_POST['action'] === 'cancel') {
        $db->prepare("DELETE FROM reservations WHERE reservation_id = ?")->execute([$resId]);
        setFlash('info', 'Reservation cancelled.');
    }
    header('Location: ' . BASE_URL . '/admin/reservations.php');
    exit;
}

$stmt = $db->query("
    SELECT r.*, 
           s.student_fname, s.student_lname, 
           b.book_name AS book_title, 
           b.book_image
    FROM reservations r
    JOIN students s ON r.student_id = s.student_id
    JOIN books b ON r.book_id = b.book_id
    ORDER BY r.reserved_at DESC
");
$reservations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservations — Nomuk Admin</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="admin-page">
<div class="app-layout">
    <?php renderAdminSidebar('reservations'); ?>
    <main class="main-content">
        <?php renderTopHeader('Pending Requests'); ?>
        <div class="container">
            <?= renderFlash() ?>
            
            <div class="view-header" style="margin-bottom: 25px;">
                <h1 style="font-weight: 800; font-size: 1.8rem;">Book Reservations</h1>
                <p style="color: var(--text-muted);">Manage students waiting for pickup</p>
            </div>

            <div class="table-card" style="background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden;">
                <table class="modern-table" style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #fafbfc; text-align: left;">
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Book</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Reserved By</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Expires At</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted); text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservations as $r): ?>
                        <tr style="border-bottom: 1px solid #f8f9fa;">
                            <td style="padding: 16px 24px;">
                                <div style="display:flex; align-items:center; gap:12px;">
                                    <img src="<?= BASE_URL ?>/assets/uploads/books/<?= $r['book_image'] ?: 'default.png' ?>" style="width:35px; height:50px; object-fit:cover; border-radius:4px;">
                                    <div style="font-weight: 700; font-size: 14px;"><?= clean($r['book_title']) ?></div>
                                </div>
                            </td>
                            <td style="padding: 16px 24px;">
                                <div style="font-weight: 600;"><?= clean($r['student_fname'] . ' ' . $r['student_lname']) ?></div>
                                <div style="font-size: 12px; color: var(--text-muted);"><?= date('M d, g:i A', strtotime($r['reserved_at'])) ?></div>
                            </td>
                            <td style="padding: 16px 24px;">
                                <span class="badge badge-expired"><?= date('M d, Y', strtotime($r['expires_at'])) ?></span>
                            </td>
                            <td style="padding: 16px 24px; text-align: right; display:flex; gap:10px; justify-content: flex-end;">
                                <form method="POST">
                                    <input type="hidden" name="reservation_id" value="<?= $r['reservation_id'] ?>">
                                    <input type="hidden" name="action" value="approve">
                                    <button type="submit" class="btn-primary" style="padding: 8px 16px; font-size: 12px; border:none; border-radius:10px; cursor:pointer;">Release Book</button>
                                </form>
                                <form method="POST">
                                    <input type="hidden" name="reservation_id" value="<?= $r['reservation_id'] ?>">
                                    <input type="hidden" name="action" value="cancel">
                                    <button type="submit" class="btn-outline" style="padding: 8px 16px; font-size: 12px; border-radius:10px; cursor:pointer;">Cancel</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($reservations)): ?>
                            <tr><td colspan="4" style="padding: 40px; text-align: center; color: var(--text-muted);">No pending reservations.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>