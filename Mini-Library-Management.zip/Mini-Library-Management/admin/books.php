<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
require_once __DIR__ . '/../includes/layout.php';

$db = getDB();

// ── LOGIC PRESERVED: Handle POST actions ──────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name      = trim($_POST['book_name'] ?? '');
        $author    = trim($_POST['book_author'] ?? '');
        $category  = trim($_POST['book_category'] ?? '');
        $isbn      = trim($_POST['isbn'] ?? '');
        $publisher = trim($_POST['publisher'] ?? '');
        $year      = intval($_POST['publish_year'] ?? 0);
        $copies    = max(1, intval($_POST['total_copies'] ?? 1));
        $aisle     = intval($_POST['aisle_id'] ?? 0) ?: null;
        $desc      = trim($_POST['description'] ?? '');

        if ($name && $author && $category) {
            if ($action === 'add') {
                $stmt = $db->prepare("INSERT INTO books (book_name,book_author,book_category,isbn,publisher,publish_year,total_copies,available_copies,aisle_id,description)
                                      VALUES (?,?,?,?,?,?,?,?,?,?)");
                $stmt->execute([$name,$author,$category,$isbn ?: null,$publisher ?: null,$year ?: null,$copies,$copies,$aisle,$desc ?: null]);
                setFlash('success', 'Book added successfully.');
            } else {
                $bookId  = intval($_POST['book_id']);
                $avail   = intval($_POST['available_copies'] ?? 0);
                $stmt = $db->prepare("UPDATE books SET book_name=?,book_author=?,book_category=?,isbn=?,publisher=?,publish_year=?,total_copies=?,available_copies=?,aisle_id=?,description=? WHERE book_id=?");
                $stmt->execute([$name,$author,$category,$isbn ?: null,$publisher ?: null,$year ?: null,$copies,min($avail,$copies),$aisle,$desc ?: null,$bookId]);
                setFlash('success', 'Book updated successfully.');
            }
        } else {
            setFlash('error', 'Required fields are missing.');
        }
    }

    if ($action === 'delete') {
        $bookId = intval($_POST['book_id']);
        $stmt = $db->prepare("UPDATE books SET is_active=0 WHERE book_id=?");
        $stmt->execute([$bookId]);
        setFlash('success', 'Book removed from catalog.');
    }

    header('Location: ' . BASE_URL . '/admin/books.php');
    exit;
}

// ── LOGIC PRESERVED: Filters & Pagination ──────────────────────────────────
$search    = trim($_GET['search'] ?? '');
$catFilter = trim($_GET['category'] ?? '');
$page      = max(1, intval($_GET['page'] ?? 1));
$perPage   = 10; // Adjusted for better view

$where = ['b.is_active = 1'];
$params = [];

if ($search) {
    // If your DB doesn't support MATCH, use LIKE as a fallback:
    $where[] = "(b.book_name LIKE ? OR b.book_author LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
if ($catFilter) {
    $where[] = 'b.book_category = ?';
    $params[] = $catFilter;
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

$countStmt = $db->prepare("SELECT COUNT(*) FROM books b $whereSQL");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();

$pag = paginate($total, $perPage, $page);

$stmt = $db->prepare("SELECT b.*, a.aisle_number, a.aisle_category
                      FROM books b LEFT JOIN books_aisle a ON a.aisle_id = b.aisle_id
                      $whereSQL ORDER BY b.book_name ASC LIMIT {$pag['per_page']} OFFSET {$pag['offset']}");
$stmt->execute($params);
$books = $stmt->fetchAll();

$aisles = $db->query("SELECT * FROM books_aisle ORDER BY aisle_number")->fetchAll();
$categories = $db->query("SELECT DISTINCT book_category FROM books WHERE is_active=1 ORDER BY book_category")->fetchAll(PDO::FETCH_COLUMN);
$baseUrl = BASE_URL . '/admin/books.php?search=' . urlencode($search) . '&category=' . urlencode($catFilter);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Catalog — <?= SITE_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        .avail-bar { background: #eee; height: 6px; border-radius: 10px; overflow: hidden; margin-top: 5px; width: 80px; }
        .avail-fill { background: var(--primary); height: 100%; border-radius: 10px; }
        .avail-fill.low { background: #ffab00; }
        .avail-fill.none { background: #ff5630; }
        
        /* Modal Styles */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
        .modal-overlay.hidden { display: none; }
        .modal { background: white; width: 90%; max-width: 600px; border-radius: 20px; padding: 30px; }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px; }
    </style>
</head>
<body class="admin-page">

    <div class="app-layout">
        <?php renderAdminSidebar('books'); ?>

        <main class="main-content">
            <?php renderTopHeader('Library Catalog'); ?>

            <div class="container">
                <div style="margin-bottom: 20px;"><?= renderFlash() ?></div>

                <div class="view-header" style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px;">
                    <div>
                        <h1 style="font-size: 2rem; font-weight: 800;">Book Catalog</h1>
                        <p style="color: var(--text-muted);"><?= number_format($total) ?> Books in collection</p>
                    </div>
                    <button class="btn-primary" onclick="openModal('addModal')" style="padding: 12px 24px; border-radius: 12px; font-weight: 700; background: var(--primary); color: white; border: none; cursor: pointer;">
                        + Add New Book
                    </button>
                </div>

                <div class="table-card" style="background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden;">
                    <div style="padding: 20px; border-bottom: 1px solid #f0f0f0;">
                        <form method="GET" style="display: flex; gap: 15px;">
                            <input type="text" name="search" placeholder="Search by title or author..." value="<?= clean($search) ?>" 
                                   style="flex: 1; padding: 12px; border-radius: 10px; border: 1px solid #ddd; outline: none;">
                            <select name="category" onchange="this.form.submit()" style="padding: 12px; border-radius: 10px; border: 1px solid #ddd;">
                                <option value="">All Categories</option>
                                <?php foreach ($categories as $cat): ?>
                                    <option value="<?= clean($cat) ?>" <?= $catFilter === $cat ? 'selected' : '' ?>><?= clean($cat) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn-primary" style="padding: 0 20px; border-radius: 10px;">Filter</button>
                        </form>
                    </div>

                    <table class="modern-table" style="width: 100%; border-collapse: collapse;">
                        <thead>
                            <tr style="background: #fafbfc; text-align: left; border-bottom: 1px solid #f0f0f0;">
                                <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Book Details</th>
                                <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Category</th>
                                <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Stock</th>
                                <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Aisle</th>
                                <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted); text-align: right;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($books as $book): ?>
                            <tr style="border-bottom: 1px solid #f8f9fa;">
                                <td style="padding: 16px 24px;">
                                    <div style="font-weight: 700; color: var(--text-main);"><?= clean($book['book_name']) ?></div>
                                    <div style="font-size: 12px; color: var(--text-muted);"><?= clean($book['book_author']) ?></div>
                                </td>
                                <td style="padding: 16px 24px; font-size: 14px;"><?= clean($book['book_category']) ?></td>
                                <td style="padding: 16px 24px;">
                                    <div style="font-size: 13px; font-weight: 600;"><?= $book['available_copies'] ?> / <?= $book['total_copies'] ?></div>
                                    <div class="avail-bar">
                                        <?php 
                                            $pct = ($book['available_copies'] / $book['total_copies']) * 100;
                                            $colorClass = $pct < 20 ? 'none' : ($pct < 50 ? 'low' : '');
                                        ?>
                                        <div class="avail-fill <?= $colorClass ?>" style="width: <?= $pct ?>%"></div>
                                    </div>
                                </td>
                                <td style="padding: 16px 24px; font-size: 14px;"><?= $book['aisle_number'] ? 'Aisle '.$book['aisle_number'] : '—' ?></td>
                                <td style="padding: 16px 24px; text-align: right;">
                                    <button onclick='editBook(<?= json_encode($book) ?>)' style="background: none; border: none; cursor: pointer; color: var(--primary); margin-right: 10px;">Edit</button>
                                    <button onclick="confirmDelete(<?= $book['book_id'] ?>, '<?= addslashes($book['book_name']) ?>')" style="background: none; border: none; cursor: pointer; color: var(--danger);">Delete</button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div style="padding: 20px;">
                        <?= renderPagination($pag, $baseUrl) ?>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <div class="modal-overlay hidden" id="addModal">
        <div class="modal">
            <h2 style="margin-bottom: 20px;">Add New Book</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="form-row">
                    <div class="form-group">
                        <label>Book Name</label>
                        <input type="text" name="book_name" required style="width:100%; padding:10px; border-radius:8px; border:1px solid #ddd;">
                    </div>
                    <div class="form-group">
                        <label>Author</label>
                        <input type="text" name="book_author" required style="width:100%; padding:10px; border-radius:8px; border:1px solid #ddd;">
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label>Category</label>
                        <input type="text" name="book_category" required style="width:100%; padding:10px; border-radius:8px; border:1px solid #ddd;">
                    </div>
                    <div class="form-group">
                        <label>Total Copies</label>
                        <input type="number" name="total_copies" value="1" required style="width:100%; padding:10px; border-radius:8px; border:1px solid #ddd;">
                    </div>
                </div>
                <div style="text-align: right; margin-top: 20px;">
                    <button type="button" onclick="closeModal('addModal')" style="padding: 10px 20px; border: none; background: #eee; border-radius: 8px; cursor: pointer;">Cancel</button>
                    <button type="submit" style="padding: 10px 20px; border: none; background: var(--primary); color: white; border-radius: 8px; cursor: pointer;">Save Book</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
        function closeModal(id) { document.getElementById(id).classList.add('hidden'); }
        function confirmDelete(id, name) {
            if(confirm("Remove '" + name + "' from catalog?")) {
                let f = document.createElement('form');
                f.method = 'POST';
                f.innerHTML = `<input type="hidden" name="action" value="delete"><input type="hidden" name="book_id" value="${id}">`;
                document.body.appendChild(f);
                f.submit();
            }
        }
        function editBook(book) {
            // Populate an edit modal here or use a prompt for now
            alert("Edit feature for: " + book.book_name);
        }
    </script>
</body>
</html>