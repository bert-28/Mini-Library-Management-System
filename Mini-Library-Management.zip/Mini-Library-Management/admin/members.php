<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
require_once __DIR__ . '/../includes/layout.php';

$db = getDB();

// ── LOGIC PRESERVED: Handle POST ───────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'toggle_status') {
        $userId = intval($_POST['user_id']);
        $db->prepare("UPDATE users SET is_active = NOT is_active WHERE user_id=?")->execute([$userId]);
        $db->prepare("UPDATE students SET is_active = NOT is_active WHERE user_id=?")->execute([$userId]);
        setFlash('success', 'Member status updated.');
    }

    if ($action === 'edit_student') {
        $sid     = intval($_POST['student_id']);
        $fname   = trim($_POST['fname'] ?? '');
        $mname   = trim($_POST['mname'] ?? '');
        $lname   = trim($_POST['lname'] ?? '');
        $grade   = trim($_POST['grade'] ?? '');
        $contact = trim($_POST['contact'] ?? '');

        if ($fname && $lname) {
            $db->prepare("UPDATE students SET student_fname=?,student_mname=?,student_lname=?,grade_level=?,contact_no=? WHERE student_id=?")
               ->execute([$fname, $mname ?: null, $lname, $grade ?: null, $contact ?: null, $sid]);
            setFlash('success', 'Member profile updated.');
        } else {
            setFlash('error', 'First and last name are required.');
        }
    }

    header('Location: ' . BASE_URL . '/admin/members.php');
    exit;
}

// ── LOGIC PRESERVED: Filters ───────────────────────────────────────────────
$search = trim($_GET['search'] ?? '');
$status = $_GET['status'] ?? '';
$page   = max(1, intval($_GET['page'] ?? 1));
$perPage = 12;

$where  = ['u.role = "student"'];
$params = [];

if ($search) {
    $where[] = '(s.student_fname LIKE ? OR s.student_lname LIKE ? OR u.username LIKE ? OR u.email LIKE ?)';
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}
if ($status === 'active') {
    $where[] = 'u.is_active = 1';
} elseif ($status === 'inactive') {
    $where[] = 'u.is_active = 0';
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

$countStmt = $db->prepare("SELECT COUNT(*) FROM users u JOIN students s ON s.user_id=u.user_id $whereSQL");
$countStmt->execute($params);
$total = (int)$countStmt->fetchColumn();
$pag = paginate($total, $perPage, $page);

$stmt = $db->prepare("
    SELECT u.user_id, u.username, u.email, u.is_active, u.created_at,
           s.student_id, s.student_fname, s.student_mname, s.student_lname,
           s.grade_level, s.contact_no,
           (SELECT COUNT(*) FROM borrow_records br WHERE br.student_id=s.student_id AND br.status IN ('borrowed','overdue')) AS active_borrows,
           (SELECT COALESCE(SUM(f.total_amount),0) FROM fines f WHERE f.student_id=s.student_id AND f.is_paid=0) AS unpaid_fines
    FROM users u
    JOIN students s ON s.user_id = u.user_id
    $whereSQL
    ORDER BY u.created_at DESC
    LIMIT {$pag['per_page']} OFFSET {$pag['offset']}
");
$stmt->execute($params);
$members = $stmt->fetchAll();

$baseUrl = BASE_URL . '/admin/members.php?search=' . urlencode($search) . '&status=' . urlencode($status);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Members — Nomuk Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        .sidebar-avatar { 
            width: 40px; height: 40px; border-radius: 12px; 
            background: var(--primary-light); color: var(--primary);
            display: flex; align-items: center; justify-content: center;
            font-weight: 800; font-size: 1.1rem;
        }
        .fine-indicator { color: #ff5630; font-weight: 700; }
        .borrow-badge { 
            background: #e3f2fd; color: #1976d2; 
            padding: 4px 10px; border-radius: 8px; font-weight: 700; font-size: 12px;
        }
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 1000; display: flex; align-items: center; justify-content: center; backdrop-filter: blur(4px); }
        .modal-overlay.hidden { display: none; }
        .modal { background: white; width: 95%; max-width: 550px; border-radius: 24px; padding: 32px; box-shadow: 0 20px 40px rgba(0,0,0,0.2); }
        .form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 15px; }
    </style>
</head>
<body class="admin-page">
<div class="app-layout">
    <?php renderAdminSidebar('members'); ?>
    
    <main class="main-content">
        <?php renderTopHeader('Member Directory'); ?>
        
        <div class="container">
            <?= renderFlash() ?>

            <div class="view-header" style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 30px;">
                <div>
                    <h1 style="font-size: 2rem; font-weight: 800;">Library Members</h1>
                    <p style="color: var(--text-muted);"><?= number_format($total) ?> Registered students</p>
                </div>
            </div>

            <div class="table-card" style="background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden;">
                <div style="padding: 20px; border-bottom: 1px solid #f0f0f0;">
                    <form method="GET" style="display: flex; gap: 15px; flex-wrap: wrap;">
                        <input type="text" name="search" placeholder="Search name or username..." value="<?= clean($search) ?>" 
                               style="flex: 1; min-width: 250px; padding: 12px 20px; border-radius: 12px; border: 1px solid #ddd; outline: none;">
                        
                        <select name="status" class="filter-select" onchange="this.form.submit()" style="padding: 12px; border-radius: 12px; border: 1px solid #ddd;">
                            <option value="">All Status</option>
                            <option value="active" <?= $status==='active' ? 'selected' : '' ?>>Active Only</option>
                            <option value="inactive" <?= $status==='inactive' ? 'selected' : '' ?>>Inactive Only</option>
                        </select>

                        <?php if($search || $status): ?>
                            <a href="members.php" class="btn-outline" style="padding: 12px 20px; text-decoration: none; font-size: 14px;">Clear Filters</a>
                        <?php endif; ?>
                    </form>
                </div>

                <table class="modern-table" style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr style="background: #fafbfc; text-align: left; border-bottom: 1px solid #f0f0f0;">
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Member</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Academic Info</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Activity</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted);">Status</th>
                            <th style="padding: 16px 24px; font-size: 11px; text-transform: uppercase; color: var(--text-muted); text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($members)): ?>
                            <tr><td colspan="5" style="padding: 50px; text-align: center; color: var(--text-muted);">No members found.</td></tr>
                        <?php endif; ?>
                        
                        <?php foreach ($members as $m): ?>
                        <tr style="border-bottom: 1px solid #f8f9fa;">
                            <td style="padding: 16px 24px;">
                                <div style="display: flex; align-items: center; gap: 15px;">
                                    <div class="sidebar-avatar"><?= strtoupper(substr($m['student_fname'], 0, 1)) ?></div>
                                    <div>
                                        <div style="font-weight: 700; color: var(--text-dark);"><?= clean($m['student_fname'] . ' ' . $m['student_lname']) ?></div>
                                        <div style="font-size: 12px; color: var(--text-muted);">@<?= clean($m['username']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td style="padding: 16px 24px;">
                                <div style="font-size: 14px; font-weight: 600;"><?= clean($m['grade_level'] ?? 'Unassigned') ?></div>
                                <div style="font-size: 12px; color: var(--text-muted);"><?= clean($m['contact_no'] ?? 'No contact') ?></div>
                            </td>
                            <td style="padding: 16px 24px;">
                                <div style="display: flex; gap: 10px; align-items: center;">
                                    <?php if ($m['active_borrows'] > 0): ?>
                                        <span class="borrow-badge"><?= $m['active_borrows'] ?> Borrowed</span>
                                    <?php endif; ?>
                                    
                                    <?php if ($m['unpaid_fines'] > 0): ?>
                                        <span class="fine-indicator">₱<?= number_format($m['unpaid_fines'], 2) ?></span>
                                    <?php endif; ?>

                                    <?php if ($m['active_borrows'] == 0 && $m['unpaid_fines'] == 0): ?>
                                        <span style="color: #999; font-size: 13px;">No active records</span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td style="padding: 16px 24px;">
                                <span class="badge <?= $m['is_active'] ? 'badge-available' : 'badge-expired' ?>">
                                    <?= $m['is_active'] ? 'Active' : 'Inactive' ?>
                                </span>
                            </td>
                            <td style="padding: 16px 24px; text-align: right;">
                                <button onclick='editMember(<?= json_encode($m) ?>)' style="background: none; border: none; cursor: pointer; color: var(--primary); font-weight: 600; margin-right: 15px;">Edit</button>
                                
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="toggle_status">
                                    <input type="hidden" name="user_id" value="<?= $m['user_id'] ?>">
                                    <button type="submit" style="background: none; border: none; cursor: pointer; color: <?= $m['is_active'] ? '#ff5630' : '#36b37e' ?>; font-weight: 600;">
                                        <?= $m['is_active'] ? 'Deactivate' : 'Activate' ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <div style="padding: 20px;">
                    <?= renderPagination($pag, $baseUrl) ?>
                </div>
            </div>
        </div>
    </main>
</div>

<div class="modal-overlay hidden" id="editModal">
    <div class="modal">
        <h2 style="margin-bottom: 25px; font-weight: 800;">Edit Member Profile</h2>
        <form method="POST">
            <input type="hidden" name="action" value="edit_student">
            <input type="hidden" name="student_id" id="editStudentId">
            
            <div class="form-row">
                <div class="form-group">
                    <label style="display:block; margin-bottom:8px; font-weight:600; font-size:14px;">First Name</label>
                    <input type="text" name="fname" id="editFname" required style="width:100%; padding:12px; border-radius:12px; border:1px solid #ddd;">
                </div>
                <div class="form-group">
                    <label style="display:block; margin-bottom:8px; font-weight:600; font-size:14px;">Last Name</label>
                    <input type="text" name="lname" id="editLname" required style="width:100%; padding:12px; border-radius:12px; border:1px solid #ddd;">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label style="display:block; margin-bottom:8px; font-weight:600; font-size:14px;">Grade Level</label>
                    <select name="grade" id="editGrade" style="width:100%; padding:12px; border-radius:12px; border:1px solid #ddd;">
                        <?php foreach(['Grade 7','Grade 8','Grade 9','Grade 10','Grade 11','Grade 12'] as $g): ?>
                            <option value="<?= $g ?>"><?= $g ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label style="display:block; margin-bottom:8px; font-weight:600; font-size:14px;">Contact No.</label>
                    <input type="text" name="contact" id="editContact" style="width:100%; padding:12px; border-radius:12px; border:1px solid #ddd;">
                </div>
            </div>

            <div style="margin-top: 30px; display: flex; justify-content: flex-end; gap: 12px;">
                <button type="button" onclick="closeModal('editModal')" class="btn-outline" style="padding: 12px 24px; border-radius: 12px; cursor: pointer;">Cancel</button>
                <button type="submit" class="btn-primary" style="padding: 12px 24px; border-radius: 12px; border: none; background: var(--primary); color: white; font-weight: 700; cursor: pointer;">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(id) { document.getElementById(id).classList.remove('hidden'); }
function closeModal(id) { document.getElementById(id).classList.add('hidden'); }

function editMember(m) {
    document.getElementById('editStudentId').value = m.student_id;
    document.getElementById('editFname').value     = m.student_fname;
    document.getElementById('editLname').value     = m.student_lname;
    document.getElementById('editContact').value   = m.contact_no || '';
    document.getElementById('editGrade').value     = m.grade_level || '';
    openModal('editModal');
}

// Close modal on background click
document.querySelector('.modal-overlay').addEventListener('click', function(e) {
    if (e.target === this) closeModal('editModal');
});
</script>
</body>
</html>