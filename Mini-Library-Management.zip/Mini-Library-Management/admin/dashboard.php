<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin(); // Security gate
require_once __DIR__ . '/../includes/layout.php';

$stats = getDashboardStats();
$db    = getDB();

// Fetch Recent Activity
$recentBorrows = $db->query("
    SELECT br.borrow_id, br.due_date, br.status,
           CONCAT(s.student_fname,' ',s.student_lname) AS student_name,
           b.book_name
    FROM borrow_records br
    JOIN students s ON s.student_id = br.student_id
    JOIN books b    ON b.book_id    = br.book_id
    ORDER BY br.borrow_id DESC LIMIT 6
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — Nomuk Library</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="admin-dashboard">

    <div class="app-layout">
        <?php renderAdminSidebar('dashboard'); ?>

        <main class="main-content">
            <?php renderTopHeader('Dashboard'); ?>

            <div class="container">
                <div class="view-header" style="margin-bottom: 30px;">
                    <div class="view-title">
                        <h1 style="font-size: 2rem; font-weight: 800; color: var(--text-main);">Main Dashboard</h1>
                        <p style="color: var(--text-muted); font-size: 0.9rem;">Home / <span style="color: var(--primary);">Dashboard</span></p>
                    </div>
                    <a href="borrow.php" class="btn-add" style="background: var(--primary); color: white; padding: 12px 24px; border-radius: 12px; text-decoration: none; font-weight: 700; display: inline-flex; align-items: center; gap: 8px;">
                        <?= icons('plus') ?> Issue Book
                    </a>
                </div>

                <div class="stats-grid">
                    <div class="stat-card">
                        <span class="stat-label">TOTAL BOOKS</span>
                        <h2 class="stat-number"><?= number_format($stats['total_books']) ?></h2>
                    </div>
                    <div class="stat-card">
                        <span class="stat-label">REGISTERED MEMBERS</span>
                        <h2 class="stat-number"><?= number_format($stats['total_students']) ?></h2>
                    </div>
                    <div class="stat-card">
                        <span class="stat-label">ACTIVE BORROWS</span>
                        <h2 class="stat-number"><?= number_format($stats['active_borrows']) ?></h2>
                    </div>
                    <div class="stat-card overdue" style="border-bottom: 4px solid var(--danger);">
                        <span class="stat-label" style="color: var(--danger);">OVERDUE BOOKS</span>
                        <h2 class="stat-number" style="color: var(--danger);"><?= number_format($stats['overdue_count']) ?></h2>
                    </div>
                </div>

                <div class="table-card" style="margin-top: 30px; background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden;">
                    <div class="table-header" style="padding: 24px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center;">
                        <h2 style="font-size: 1.25rem; font-weight: 700;">Recent Borrow Activity</h2>
                        <a href="reports.php" style="color: var(--primary); font-size: 0.85rem; font-weight: 700; text-decoration: none;">View Reports</a>
                    </div>
                    
                    <div style="overflow-x: auto;">
                        <table class="modern-table" style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #fafbfc; border-bottom: 1px solid var(--border);">
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Student</th>
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Book Title</th>
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Due Date</th>
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($recentBorrows)): ?>
                                    <tr><td colspan="4" style="padding: 40px; text-align: center; color: var(--text-muted);">No recent activity recorded.</td></tr>
                                <?php else: ?>
                                    <?php foreach ($recentBorrows as $row): ?>
                                    <tr style="border-bottom: 1px solid var(--border);">
                                        <td style="padding: 16px 24px;"><strong><?= htmlspecialchars($row['student_name']) ?></strong></td>
                                        <td style="padding: 16px 24px; color: var(--text-main);"><?= htmlspecialchars($row['book_name']) ?></td>
                                        <td style="padding: 16px 24px; color: var(--text-muted);"><?= date('M d, Y', strtotime($row['due_date'])) ?></td>
                                        <td style="padding: 16px 24px;">
                                            <span class="status-pill <?= $row['status'] ?>" style="padding: 6px 12px; border-radius: 20px; font-size: 10px; font-weight: 800; text-transform: uppercase; background: <?= $row['status'] == 'overdue' ? '#ffebee' : '#e3f2fd' ?>; color: <?= $row['status'] == 'overdue' ? 'var(--danger)' : 'var(--primary)' ?>;">
                                                <?= $row['status'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

</body>
</html>