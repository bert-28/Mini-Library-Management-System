<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin(); 
require_once __DIR__ . '/../includes/layout.php';

$db = getDB(); 

// --- LOGIC PRESERVED ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = intval($_POST['student_id']);
    $book_id = intval($_POST['book_id']);
    $due_date = $_POST['due_date'];

    $book = $db->prepare("SELECT available_copies FROM books WHERE book_id = ?");
    $book->execute([$book_id]);
    $avail = $book->fetchColumn();

    if ($avail > 0) {
        try {
            $stmt = $db->prepare("INSERT INTO borrow_records (student_id, book_id, borrow_date, due_date, status) VALUES (?, ?, CURDATE(), ?, 'borrowed')");
            $stmt->execute([$student_id, $book_id, $due_date]);
            setFlash('success', 'Book issued successfully!'); 
        } catch (Exception $e) {
            setFlash('error', 'Error: ' . $e->getMessage());
        }
    } else {
        setFlash('error', 'No copies available!');
    }
}

$students = $db->query("SELECT student_id, student_fname, student_lname FROM students WHERE is_active = 1 ORDER BY student_fname ASC")->fetchAll();
$books = $db->query("SELECT book_id, book_name FROM books WHERE available_copies > 0 ORDER BY book_name ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Issue Book — <?= SITE_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <style>
        /* UI Centering Logic */
        .center-wrapper {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding-top: 20px;
            min-height: 70vh;
        }
        
        .form-card {
            background: white;
            padding: 40px;
            border-radius: 24px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.05);
            width: 100%;
            max-width: 550px; /* Optimal width for readability */
        }

        .form-group label {
            display: block;
            font-weight: 700;
            margin-bottom: 12px;
            color: var(--text-main);
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.8px;
        }

        .form-control {
            width: 100%;
            padding: 15px;
            border-radius: 14px;
            border: 2px solid #f1f5f9;
            background: #f8fafc;
            outline: none;
            font-family: inherit;
            font-size: 15px;
            color: var(--text-main);
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: var(--primary);
            background: white;
            box-shadow: 0 0 0 4px rgba(67, 24, 255, 0.1);
        }
    </style>
</head>
<body class="admin-page">

    <div class="app-layout">
        <?php renderAdminSidebar('borrow'); ?>

        <main class="main-content">
            <?php renderTopHeader('Issue New Book'); ?>

            <div class="container">
                <?= renderFlash() ?>

                <div class="view-header" style="text-align: center; margin-bottom: 40px;">
                    <h1 style="font-size: 2.2rem; font-weight: 800; color: var(--text-main); margin-bottom: 8px;">Issue Book</h1>
                    <p style="color: var(--text-muted); font-size: 0.95rem;">Home / <span style="color: var(--primary); font-weight: 600;">Borrow System</span></p>
                </div>

                <div class="center-wrapper">
                    <div class="form-card">
                        <form method="POST">
                            <div class="form-group" style="margin-bottom: 25px;">
                                <label>Select Student</label>
                                <select name="student_id" required class="form-control">
                                    <option value="" disabled selected>Choose a student...</option>
                                    <?php foreach($students as $s): ?>
                                        <option value="<?= $s['student_id'] ?>"><?= clean($s['student_fname'] . ' ' . $s['student_lname']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group" style="margin-bottom: 25px;">
                                <label>Select Book</label>
                                <select name="book_id" required class="form-control">
                                    <option value="" disabled selected>Choose a book...</option>
                                    <?php foreach($books as $b): ?>
                                        <option value="<?= $b['book_id'] ?>"><?= clean($b['book_name']) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="form-group" style="margin-bottom: 35px;">
                                <label>Due Date</label>
                                <input type="date" name="due_date" required 
                                       value="<?= date('Y-m-d', strtotime('+'.LOAN_DAYS.' days')) ?>" 
                                       class="form-control">
                            </div>

                            <button type="submit" style="width: 100%; background: var(--primary); color: white; border: none; padding: 18px; border-radius: 16px; font-weight: 700; font-size: 16px; cursor: pointer; transition: all 0.4s ease; box-shadow: 0 10px 25px rgba(67, 24, 255, 0.25);">
                                Confirm & Issue Book
                            </button>
                        </form>
                    </div>
                </div>
                </div>
        </main>
    </div>

</body>
</html>