<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
require_once __DIR__ . '/../includes/layout.php';

$db = getDB();

// --- Handle Actions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $resId = intval($_POST['reservation_id']);
    if ($_POST['action'] === 'cancel') {
        $db->prepare("DELETE FROM reservations WHERE reservation_id = ?")->execute([$resId]);
        setFlash('info', 'Reservation cancelled.');
    }
    header('Location: ' . BASE_URL . '/admin/reservations.php');
    exit;
}

// --- The Fixed Query ---
// 1. Used b.book_name instead of b.book_title
// 2. Used r.reservation_date instead of r.reserved_at
$stmt = $db->query("
    SELECT r.*, 
           s.student_fname, s.student_lname, 
           b.book_name AS book_title, 
           b.book_image
    FROM reservations r
    JOIN students s ON r.student_id = s.student_id
    JOIN books b ON r.book_id = b.book_id
    ORDER BY r.reservation_date DESC
");
$reservations = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reservations — Nomuk Admin</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body class="admin-page">
<div class="app-layout">
    <?php renderAdminSidebar('reservations'); ?>
    <main class="main-content">
        <?php renderTopHeader('Reservation Management'); ?>
        <div class="container">
            <?= renderFlash() ?>
            
            <div class="view-header">
                <h1 style="font-weight: 800;">Book Reservations</h1>
                <p style="color: var(--text-muted);">Manage pending student pickups</p>
            </div>

            <div class="table-card">
                <table class="modern-table">
                    <thead>
                        <tr>
                            <th>Book</th>
                            <th>Student</th>
                            <th>Date Reserved</th>
                            <th>Expiry</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($reservations as $r): ?>
                        <tr>
                            <td>
                                <div style="display:flex; align-items:center; gap:12px;">
                                    <img src="<?= BASE_URL ?>/assets/uploads/books/<?= $r['book_image'] ?: 'default.png' ?>" style="width:35px; height:50px; object-fit:cover; border-radius:4px;">
                                    <strong><?= clean($r['book_title']) ?></strong>
                                </div>
                            </td>
                            <td><?= clean($r['student_fname'] . ' ' . $r['student_lname']) ?></td>
                            <td><?= date('M d, Y', strtotime($r['reservation_date'])) ?></td>
                            <td>
                                <span class="badge" style="background:#fff0f0; color:#ff5630;">
                                    <?= $r['expiry_date'] ? date('M d, Y', strtotime($r['expiry_date'])) : 'No Expiry' ?>
                                </span>
                            </td>
                            <td style="text-align: right;">
                                <form method="POST" onsubmit="return confirm('Cancel this reservation?')">
                                    <input type="hidden" name="reservation_id" value="<?= $r['reservation_id'] ?>">
                                    <input type="hidden" name="action" value="cancel">
                                    <button type="submit" class="btn-outline" style="padding: 6px 12px; font-size: 12px;">Cancel</button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</div>
</body>
</html>