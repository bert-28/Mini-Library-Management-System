<?php
require_once __DIR__ . '/../includes/config.php';
requireAdmin(); 
require_once __DIR__ . '/../includes/layout.php';

$db = getDB(); 

// --- LOGIC PRESERVED: Handling the Return Submission ---
if (isset($_POST['return_id'])) {
    $borrow_id = intval($_POST['return_id']);
    
    $record = $db->prepare("SELECT student_id, book_id FROM borrow_records WHERE borrow_id = ?");
    $record->execute([$borrow_id]);
    $data = $record->fetch();

    if ($data) {
        try {
            // 1. Log the return record
            $stmt = $db->prepare("INSERT INTO return_records (borrow_id, student_id, book_id, return_date) VALUES (?, ?, ?, CURDATE())");
            $stmt->execute([$borrow_id, $data['student_id'], $data['book_id']]);
            
            // 2. Mark borrow record as returned
            $db->prepare("UPDATE borrow_records SET status = 'returned' WHERE borrow_id = ?")->execute([$borrow_id]);
            
            // 3. Update book status back to available
            $db->prepare("UPDATE books SET status = 'available' WHERE book_id = ?")->execute([$data['book_id']]);
            
            setFlash('success', 'Book returned successfully!'); 
        } catch (Exception $e) {
            setFlash('error', 'Update failed: ' . $e->getMessage());
        }
    }
}

// --- LOGIC PRESERVED: Fetching Active Borrows ---
$borrows = $db->query("SELECT br.*, b.book_name, s.student_fname, s.student_lname 
                       FROM borrow_records br 
                       JOIN books b ON br.book_id = b.book_id 
                       JOIN students s ON br.student_id = s.student_id 
                       WHERE br.status IN ('borrowed', 'overdue')
                       ORDER BY br.due_date ASC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Returns — Nomuk</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
</head>
<body class="admin-page">

    <div class="app-layout">
        <?php renderAdminSidebar('returns'); ?>

        <main class="main-content">
            <?php renderTopHeader('Process Returns'); ?>

            <div class="container">
                <div style="margin-bottom: 20px;">
                    <?= renderFlash() ?>
                </div>

                <div class="view-header" style="margin-bottom: 30px;">
                    <div class="view-title">
                        <h1 style="font-size: 2rem; font-weight: 800; color: var(--text-main);">Process Returns</h1>
                        <p style="color: var(--text-muted); font-size: 0.9rem;">Home / <span style="color: var(--primary);">Returns Management</span></p>
                    </div>
                </div>

                <div class="table-card" style="background: white; border-radius: 20px; box-shadow: 0 10px 30px rgba(0,0,0,0.05); overflow: hidden;">
                    <div class="table-header" style="padding: 24px; border-bottom: 1px solid var(--border);">
                        <h2 style="font-size: 1.1rem; font-weight: 700;">Active Loans</h2>
                    </div>

                    <div style="overflow-x: auto;">
                        <table class="modern-table" style="width: 100%; border-collapse: collapse;">
                            <thead>
                                <tr style="background: #fafbfc; border-bottom: 1px solid var(--border);">
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Student</th>
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Book Title</th>
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Due Date</th>
                                    <th style="padding: 16px 24px; text-align: left; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Status</th>
                                    <th style="padding: 16px 24px; text-align: right; font-size: 11px; color: var(--text-muted); text-transform: uppercase; letter-spacing: 1px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($borrows)): ?>
                                    <tr>
                                        <td colspan="5" style="padding: 60px; text-align: center; color: var(--text-muted);">
                                            <div style="font-size: 40px; margin-bottom: 10px;">🍃</div>
                                            No active borrows found.
                                        </td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach($borrows as $row): ?>
                                    <tr style="border-bottom: 1px solid var(--border);">
                                        <td style="padding: 18px 24px;">
                                            <div style="font-weight: 700; color: var(--text-main);"><?= clean($row['student_fname'] . ' ' . $row['student_lname']) ?></div>
                                        </td>
                                        <td style="padding: 18px 24px; color: var(--text-main);"><?= clean($row['book_name']) ?></td>
                                        <td style="padding: 18px 24px;">
                                            <span style="font-family: monospace; font-weight: 600;"><?= date('M d, Y', strtotime($row['due_date'])) ?></span>
                                        </td>
                                        <td style="padding: 18px 24px;">
                                            <span class="status-pill <?= $row['status'] ?>" style="padding: 6px 12px; border-radius: 20px; font-size: 10px; font-weight: 800; text-transform: uppercase; background: <?= $row['status'] == 'overdue' ? '#ffebee' : '#e3f2fd' ?>; color: <?= $row['status'] == 'overdue' ? 'var(--danger)' : 'var(--primary)' ?>;">
                                                <?= $row['status'] ?>
                                            </span>
                                        </td>
                                        <td style="padding: 18px 24px; text-align: right;">
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure the book has been returned in good condition?');">
                                                <input type="hidden" name="return_id" value="<?= $row['borrow_id'] ?>">
                                                <button type="submit" style="background: var(--success); color: white; border: none; padding: 8px 16px; border-radius: 10px; font-weight: 700; font-size: 12px; cursor: pointer; transition: 0.3s; box-shadow: 0 4px 12px rgba(0, 200, 83, 0.2);">
                                                    Mark Returned
                                                </button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

</body>
</html>