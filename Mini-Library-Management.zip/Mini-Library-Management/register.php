<?php
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . (isAdmin() ? '/admin/dashboard.php' : '/user/dashboard.php'));
    exit;
}

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fname    = trim($_POST['fname'] ?? '');
    $mname    = trim($_POST['mname'] ?? '');
    $lname    = trim($_POST['lname'] ?? '');
    $grade    = trim($_POST['grade'] ?? '');
    $contact  = trim($_POST['contact'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (!$fname)     $errors[] = 'First name is required.';
    if (!$lname)     $errors[] = 'Last name is required.';
    if (!$username)  $errors[] = 'Username is required.';
    if (!$email || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (empty($errors)) {
        $db = getDB();
        $stmt = $db->prepare("SELECT COUNT(*) FROM users WHERE username=? OR email=?");
        $stmt->execute([$username, $email]);
        if ($stmt->fetchColumn() > 0) {
            $errors[] = 'Username or email already exists.';
        } else {
            try {
                $db->beginTransaction();
                $stmt = $db->prepare("INSERT INTO users (username, email, password_hash, role) VALUES (?,?,?,?)");
                $stmt->execute([$username, $email, password_hash($password, PASSWORD_BCRYPT), 'student']);
                $userId = $db->lastInsertId();

                $stmt = $db->prepare("INSERT INTO students (user_id, student_fname, student_mname, student_lname, grade_level, contact_no) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$userId, $fname, $mname ?: null, $lname, $grade ?: null, $contact ?: null]);

                $db->commit();
                $success = true;
            } catch (Exception $e) {
                $db->rollBack();
                $errors[] = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Account — Nomuk Library</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4318FF;
            --primary-hover: #3311CC;
            --text-main: #1B2559;
            --text-muted: #A3AED0;
            --bg-body: #F4F7FE;
            --white: #FFFFFF;
            --error: #E53E3E;
            --success: #05CD99;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Plus Jakarta Sans', sans-serif; }

        body { background-color: var(--bg-body); min-height: 100vh; color: var(--text-main); }

        .auth-container { display: flex; min-height: 100vh; width: 100%; }

        /* Brand Hero */
        .auth-hero {
            flex: 1;
            background: linear-gradient(135deg, #4318ff 0%, #b099ff 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            color: white;
            padding: 40px;
            position: sticky;
            top: 0;
            height: 100vh;
        }

        .hero-content { text-align: center; z-index: 1; }
        .hero-content h1 { font-size: 3.5rem; font-weight: 800; letter-spacing: -2px; }
        .hero-content p { font-size: 1.1rem; opacity: 0.9; }

        /* Form Side */
        .auth-form-side {
            flex: 1.2;
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 60px 40px;
            overflow-y: auto;
        }

        .auth-card {
            width: 100%;
            max-width: 580px;
            background: white;
            padding: 40px;
            border-radius: 30px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.04);
        }

        .auth-header { margin-bottom: 30px; }
        .auth-header h2 { font-size: 1.8rem; font-weight: 800; margin-bottom: 8px; }
        .auth-header p { color: var(--text-muted); font-size: 0.95rem; }

        .section-title {
            font-size: 12px;
            font-weight: 800;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: var(--primary);
            margin: 25px 0 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .section-title::after { content: ""; flex: 1; height: 1px; background: #F4F7FE; }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .full-width { grid-column: span 2; }

        .form-group { margin-bottom: 15px; }
        .form-label { display: block; font-size: 14px; font-weight: 700; margin-bottom: 8px; }
        
        .form-input, .form-select {
            width: 100%;
            padding: 12px 18px;
            border-radius: 14px;
            border: 2px solid #E0E5F2;
            outline: none;
            font-size: 14px;
            transition: 0.3s;
        }

        .form-input:focus { border-color: var(--primary); }

        .btn-register {
            width: 100%;
            background: var(--primary);
            color: white;
            padding: 16px;
            border-radius: 16px;
            border: none;
            font-weight: 700;
            font-size: 16px;
            cursor: pointer;
            box-shadow: 0 10px 20px rgba(67, 24, 255, 0.2);
            transition: 0.3s;
            margin-top: 25px;
        }

        .btn-register:hover { background: var(--primary-hover); transform: translateY(-2px); }

        .flash { padding: 15px; border-radius: 14px; font-size: 14px; margin-bottom: 20px; font-weight: 600; text-align: center; }
        .flash-error { background: #FFF5F5; color: var(--error); }
        .flash-success { background: #E6FFFA; color: var(--success); }

        @media (max-width: 1000px) {
            .auth-hero { display: none; }
            .auth-form-side { padding: 20px; }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-hero">
            <div class="hero-content">
                <h1>NOMUK</h1>
                <p>Join our student community</p>
            </div>
        </div>

        <div class="auth-form-side">
            <div class="auth-card">
                <div class="auth-header">
                    <h2>Create Account</h2>
                    <p>Enter your details to register as a student</p>
                </div>

                <?php if ($success): ?>
                    <div class="flash flash-success">
                        ✓ Success! Your account is ready. <a href="login.php" style="color: inherit; text-decoration: underline;">Sign in here</a>
                    </div>
                <?php else: ?>

                    <?php foreach ($errors as $err): ?>
                        <div class="flash flash-error">✕ <?= htmlspecialchars($err) ?></div>
                    <?php endforeach; ?>

                    <form method="POST">
                        <div class="section-title">Personal Details</div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">First Name *</label>
                                <input type="text" name="fname" class="form-input" placeholder="John" value="<?= htmlspecialchars($_POST['fname'] ?? '') ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Last Name *</label>
                                <input type="text" name="lname" class="form-input" placeholder="Doe" value="<?= htmlspecialchars($_POST['lname'] ?? '') ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Middle Name</label>
                                <input type="text" name="mname" class="form-input" placeholder="Optional" value="<?= htmlspecialchars($_POST['mname'] ?? '') ?>">
                            </div>
                            <div class="form-group">
                                <label class="form-label">Grade Level</label>
                                <select name="grade" class="form-select">
                                    <option value="">Select Level</option>
                                    <?php foreach(['Grade 7','Grade 8','Grade 9','Grade 10','Grade 11','Grade 12'] as $g): ?>
                                        <option value="<?= $g ?>" <?= ($_POST['grade'] ?? '') === $g ? 'selected' : '' ?>><?= $g ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group full-width">
                                <label class="form-label">Contact Number</label>
                                <input type="text" name="contact" class="form-input" placeholder="09123456789" value="<?= htmlspecialchars($_POST['contact'] ?? '') ?>">
                            </div>
                        </div>

                        <div class="section-title">Account Security</div>
                        <div class="form-grid">
                            <div class="form-group full-width">
                                <label class="form-label">Username *</label>
                                <input type="text" name="username" class="form-input" placeholder="johndoe123" value="<?= htmlspecialchars($_POST['username'] ?? '') ?>" required>
                            </div>
                            <div class="form-group full-width">
                                <label class="form-label">Email Address *</label>
                                <input type="email" name="email" class="form-input" placeholder="john@example.com" value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Password *</label>
                                <input type="password" name="password" class="form-input" placeholder="Min. 6 chars" required>
                            </div>
                            <div class="form-group">
                                <label class="form-label">Confirm *</label>
                                <input type="password" name="confirm_password" class="form-input" placeholder="Repeat password" required>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn-register">Create Account</button>
                    </form>

                    <p style="text-align: center; margin-top: 25px; font-size: 14px; color: var(--text-muted);">
                        Already have an account? <a href="login.php" style="color: var(--primary); font-weight: 700; text-decoration: none;">Sign In</a>
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>