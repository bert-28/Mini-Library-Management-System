<?php
// includes/layout.php
// Shared layout components: admin sidebar, student sidebar, header

function renderAdminSidebar(string $active = ''): void {
    $user = htmlspecialchars($_SESSION['username'] ?? 'Admin', ENT_QUOTES);
    $initial = strtoupper(substr($user, 0, 1));

    $db = getDB();
    $overdueCount = $db->query("SELECT COUNT(*) FROM borrow_records WHERE status='overdue'")->fetchColumn();
    $pendingFines = $db->query("SELECT COUNT(*) FROM fines WHERE is_paid=0")->fetchColumn();

    $links = [
        'dashboard'    => ['icon' => icons('home'),     'label' => 'Dashboard',    'href' => BASE_URL . '/admin/dashboard.php'],
        'books'        => ['icon' => icons('book'),     'label' => 'Books',        'href' => BASE_URL . '/admin/books.php'],
        'members'      => ['icon' => icons('users'),    'label' => 'Members',      'href' => BASE_URL . '/admin/members.php'],
        'borrow'       => ['icon' => icons('borrow'),   'label' => 'Borrow',       'href' => BASE_URL . '/admin/borrow.php'],
        'returns'      => ['icon' => icons('return'),   'label' => 'Returns',      'href' => BASE_URL . '/admin/returns.php', 'badge' => $overdueCount],
        'reservations' => ['icon' => icons('bookmark'), 'label' => 'Reservations', 'href' => BASE_URL . '/admin/reservations.php'],
        'fines'        => ['icon' => icons('fine'),     'label' => 'Fines',        'href' => BASE_URL . '/admin/fines.php', 'badge' => $pendingFines],
        'reports'      => ['icon' => icons('chart'),    'label' => 'Reports',      'href' => BASE_URL . '/admin/reports.php'],
    ];

    echo '<aside class="sidebar" id="sidebar">';
    echo '<div class="sidebar-logo">';
    echo '<img src="' . BASE_URL . '/assets/img/logo.png" alt="Nomuk Logo" onerror="this.style.display=\'none\'">';
    echo '<div class="sidebar-logo-text"><h2>Nomuk</h2><span>Library System</span></div>';
    echo '</div>';
    echo '<nav class="sidebar-nav">';
    echo '<div class="sidebar-section-label">Main</div>';

    foreach ($links as $key => $link) {
        $isActive = $active === $key ? ' active' : '';
        $badge = isset($link['badge']) && $link['badge'] > 0
            ? '<span class="sidebar-badge">' . $link['badge'] . '</span>' : '';
        echo "<a href=\"{$link['href']}\" class=\"sidebar-link{$isActive}\">";
        echo $link['icon'];
        echo "<span>{$link['label']}</span>{$badge}";
        echo '</a>';
    }

    echo '</nav>';
    
   // --- CORRECTED FOOTER: Administrator Label + Redesigned Logout ---
    echo '<div class="sidebar-footer" style="padding: 20px; border-top: 1px solid rgba(0,0,0,0.05);">';
    
    // User Profile Section
    echo '<div class="sidebar-user" style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">';
    echo "<div class=\"sidebar-avatar\" style=\"background: #4318ff; color: white; width: 40px; height: 40px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.2rem;\">{$initial}</div>";
    echo '<div class="sidebar-user-info">';
    echo "<div style=\"font-size: 15px; font-weight: 700; color: #1B2559;\">{$user}</div>";
    echo '<div style="color: #A3AED0; font-size: 12px; font-weight: 500;">Administrator</div>'; // This restores the missing text
    echo '</div>';
    echo '</div>';
    
    // Logout Button Section (Matches image_1b485d.png)
    echo '<a href="' . BASE_URL . '/logout.php" class="logout-action" style="display: flex; align-items: center; gap: 10px; padding: 12px 16px; border-radius: 12px; color: #FF5630; text-decoration: none; font-size: 14px; font-weight: 700; background: #FFF5F2; transition: all 0.3s ease;">';
    echo icons('logout');
    echo '<span>Sign Out</span>';
    echo '</a>';
    
    echo '</div>'; // End footer
    echo '</aside>';
}

function renderStudentSidebar(string $active = ''): void {
    $user = htmlspecialchars($_SESSION['username'] ?? 'Student', ENT_QUOTES);
    $initial = strtoupper(substr($user, 0, 1));
    $studentId = getStudentIdFromUserId(getCurrentUserId());

    $overdueCount = 0;
    $fineCount = 0;
    if ($studentId) {
        $db = getDB();
        $overdueCount = $db->prepare("SELECT COUNT(*) FROM borrow_records WHERE student_id=? AND status='overdue'");
        $overdueCount->execute([$studentId]);
        $overdueCount = $overdueCount->fetchColumn();

        $fineCount = $db->prepare("SELECT COUNT(*) FROM fines WHERE student_id=? AND is_paid=0");
        $fineCount->execute([$studentId]);
        $fineCount = $fineCount->fetchColumn();
    }

    $links = [
        'dashboard'    => ['icon' => icons('home'),     'label' => 'Dashboard',    'href' => BASE_URL . '/user/dashboard.php'],
        'catalog'      => ['icon' => icons('book'),     'label' => 'Browse Books', 'href' => BASE_URL . '/user/catalog.php'],
        'my-books'     => ['icon' => icons('borrow'),   'label' => 'My Books',     'href' => BASE_URL . '/user/my-books.php', 'badge' => $overdueCount],
        'reservations' => ['icon' => icons('bookmark'), 'label' => 'Reservations', 'href' => BASE_URL . '/user/reservations.php'],
        'my-fines'     => ['icon' => icons('fine'),     'label' => 'My Fines',     'href' => BASE_URL . '/user/my-fines.php', 'badge' => $fineCount],
        'profile'      => ['icon' => icons('user'),     'label' => 'Profile',      'href' => BASE_URL . '/user/profile.php'],
    ];

    echo '<aside class="sidebar" id="sidebar">';
    echo '<div class="sidebar-logo">';
    echo '<img src="' . BASE_URL . '/assets/img/logo.png" alt="Nomuk Logo" onerror="this.style.display=\'none\'">';
    echo '<div class="sidebar-logo-text"><h2>Nomuk</h2><span>Student Portal</span></div>';
    echo '</div>';
    echo '<nav class="sidebar-nav">';
    echo '<div class="sidebar-section-label">Menu</div>';

    foreach ($links as $key => $link) {
        $isActive = $active === $key ? ' active' : '';
        $badge = isset($link['badge']) && $link['badge'] > 0
            ? '<span class="sidebar-badge">' . $link['badge'] . '</span>' : '';
        echo "<a href=\"{$link['href']}\" class=\"sidebar-link{$isActive}\">";
        echo $link['icon'];
        echo "<span>{$link['label']}</span>{$badge}";
        echo '</a>';
    }

    echo '</nav>';
    
    echo '<div class="sidebar-footer" style="padding: 15px; border-top: 1px solid rgba(255,255,255,0.05);">';
    echo '<a href="' . BASE_URL . '/logout.php" style="display: flex; align-items: center; gap: 10px; padding: 10px; border-radius: 10px; color: #ff5630; text-decoration: none; font-size: 13px; font-weight: 700; background: rgba(255, 86, 48, 0.05);">';
    echo icons('logout') . '<span>Logout</span></a>';
    echo '</div>';
    
    echo '</aside>';
}

function renderTopHeader(string $title = ''): void {
    echo '<header class="top-header">';
    echo '<button class="btn-icon btn-outline" id="sidebarToggle" style="display:none;" onclick="toggleSidebar()">' . icons('menu') . '</button>';
    echo '<div class="header-search">';
    echo icons('search');
    echo '<input type="text" placeholder="Quick search books..." id="globalSearch">';
    echo '</div>';
    echo '<div class="header-spacer"></div>';
    echo '<div class="header-actions">';
    echo '<button class="header-alert-btn" id="alertBtn" title="Availability Alerts">';
    echo icons('bell');
    echo '<span class="alert-dot" id="alertDot" style="display:none;"></span>';
    echo '</button>';
    echo '</div>';
    echo '</header>';
}

function icons(string $name): string {
    $icons = [
        'home'     => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
        'book'     => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>',
        'users'    => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>',
        'borrow'   => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="16 3 21 3 21 8"/><line x1="4" y1="20" x2="21" y2="3"/><polyline points="21 16 21 21 16 21"/><line x1="15" y1="15" x2="21" y2="21"/></svg>',
        'return'   => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.51"/></svg>',
        'bookmark' => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m19 21-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>',
        'fine'     => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>',
        'chart'    => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
        'user'     => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>',
        'logout'   => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>',
        'menu'     => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>',
        'search'   => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>',
        'bell'     => '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>',
        'plus'     => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>',
        'edit'     => '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>',
        'trash'    => '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>',
        'eye'      => '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
        'check'    => '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>',
        'x'        => '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
        'aisle'    => '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/><line x1="15" y1="3" x2="15" y2="21"/></svg>',
    ];
    return $icons[$name] ?? '';
}