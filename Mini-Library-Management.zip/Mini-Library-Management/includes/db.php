<?php
// includes/db.php
// Database connection — uses PDO for prepared statements (SQL injection safe)

define('DB_HOST', 'localhost');
define('DB_NAME', 'nomuk_library');
define('DB_USER', 'root');
define('DB_PASS', '');       // XAMPP default: empty password
define('DB_CHARSET', 'utf8mb4');

define('FINE_PER_DAY', 5.00);   // PHP 5.00 per day overdue
define('LOAN_DAYS', 7);          // Default borrow period in days
define('RESERVATION_EXPIRY', 3); // Days before a 'ready' reservation expires

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die(json_encode(['error' => 'Database connection failed: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}
