<?php
// includes/config.php
// Central config — include this at the top of every page

define('BASE_URL', '/Mini-Library-Management');   // Change if deployed elsewhere
define('SITE_NAME', 'Nomuk Library');
define('SITE_TAGLINE', 'Nomuk Summer Class');

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';

if (session_status() === PHP_SESSION_NONE) session_start();

// Run overdue check on every request (lightweight)
if (isLoggedIn()) {
    updateOverdueStatus();
}
