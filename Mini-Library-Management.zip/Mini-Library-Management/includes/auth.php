<?php
// includes/auth.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function isAdmin(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
}

function isStudent(): bool {
    return isset($_SESSION['role']) && $_SESSION['role'] === 'student';
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

function requireAdmin(): void {
    requireLogin();
    if (!isAdmin()) {
        header('Location: ' . BASE_URL . '/user/dashboard.php');
        exit;
    }
}

function requireStudent(): void {
    requireLogin();
    if (!isStudent()) {
        header('Location: ' . BASE_URL . '/admin/dashboard.php');
        exit;
    }
}

function loginUser(array $user): void {
    session_regenerate_id(true);
    $_SESSION['user_id']  = $user['user_id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['email']    = $user['email'];
    $_SESSION['role']     = $user['role'];
}

function logoutUser(): void {
    session_unset();
    session_destroy();
}

function getCurrentUserId(): int {
    return (int)($_SESSION['user_id'] ?? 0);
}

function getCurrentUsername(): string {
    return $_SESSION['username'] ?? '';
}

function getCurrentRole(): string {
    return $_SESSION['role'] ?? '';
}
