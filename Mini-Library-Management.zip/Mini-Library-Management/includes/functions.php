<?php
// includes/functions.php

require_once __DIR__ . '/db.php';

// ── Sanitization ──────────────────────────────────────────
function clean(string $str): string {
    return htmlspecialchars(trim($str), ENT_QUOTES, 'UTF-8');
}

// ── Flash messages ────────────────────────────────────────
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

function renderFlash(): string {
    $flash = getFlash();
    if (!$flash) return '';
    $icon = $flash['type'] === 'success' ? '✓' : ($flash['type'] === 'error' ? '✕' : 'ℹ');
    return "<div class=\"flash flash-{$flash['type']}\"><span class=\"flash-icon\">{$icon}</span>{$flash['message']}</div>";
}

// ── Overdue updater (run on every page load) ──────────────
function updateOverdueStatus(): void {
    $db = getDB();
    // 1. Mark borrowed books as overdue if past due date
    $db->exec("UPDATE borrow_records 
               SET status = 'overdue' 
               WHERE status = 'borrowed' AND due_date < CURDATE()");

    // 2. Sync fines table: Insert records for overdue items that don't have a fine entry yet
    $db->exec("INSERT IGNORE INTO fines (borrow_id, student_id, days_overdue, fine_amount, is_paid)
               SELECT borrow_id, student_id, DATEDIFF(CURDATE(), due_date), 
               (DATEDIFF(CURDATE(), due_date) * 5.00), 0
               FROM borrow_records WHERE status = 'overdue'");
}

// ── Book availability alert data ─────────────────────────
function getAvailabilityAlerts(): array {
    $db = getDB();
    return $db->query("SELECT book_id, book_name, available_copies, total_copies
                       FROM books
                       WHERE available_copies = 0")->fetchAll();
}

// ── Dashboard stats ───────────────────────────────────────
function getDashboardStats(): array {
    $db = getDB();
    $stats = [];
    $stats['total_books']       = $db->query("SELECT SUM(total_copies) FROM books")->fetchColumn();
    $stats['total_students']    = $db->query("SELECT COUNT(*) FROM students")->fetchColumn();
    $stats['active_borrows']    = $db->query("SELECT COUNT(*) FROM borrow_records WHERE status IN ('borrowed','overdue')")->fetchColumn();
    $stats['overdue_count']     = $db->query("SELECT COUNT(*) FROM borrow_records WHERE status='overdue'")->fetchColumn();
    $stats['pending_fines']     = $db->query("SELECT COALESCE(SUM(total_amount),0) FROM fines WHERE is_paid=0")->fetchColumn();
    $stats['reservations']      = $db->query("SELECT COUNT(*) FROM reservations WHERE status='pending'")->fetchColumn();
    return $stats;
}

// ── Student dashboard stats ───────────────────────────────
function getStudentStats(int $studentId): array {
    $db = getDB();
    $stmt = $db->prepare("SELECT
        (SELECT COUNT(*) FROM borrow_records WHERE student_id=? AND status IN ('borrowed','overdue')) AS active_borrows,
        (SELECT COUNT(*) FROM borrow_records WHERE student_id=? AND status='overdue') AS overdue,
        (SELECT COALESCE(SUM(total_amount),0) FROM fines WHERE student_id=? AND is_paid=0) AS unpaid_fines,
        (SELECT COUNT(*) FROM reservations WHERE student_id=? AND status IN ('pending','ready')) AS reservations");
    $stmt->execute([$studentId, $studentId, $studentId, $studentId]);
    return $stmt->fetch();
}

// ── Get student ID from user_id ───────────────────────────
function getStudentIdFromUserId(int $userId): ?int {
    $db = getDB();
    $stmt = $db->prepare("SELECT student_id FROM students WHERE user_id=?");
    $stmt->execute([$userId]);
    $row = $stmt->fetch();
    return $row ? (int)$row['student_id'] : null;
}

// ── Pagination helper ─────────────────────────────────────
function paginate(int $total, int $perPage, int $current): array {
    $totalPages = max(1, (int)ceil($total / $perPage));
    return [
        'total'       => $total,
        'per_page'    => $perPage,
        'current'     => $current,
        'total_pages' => $totalPages,
        'offset'      => ($current - 1) * $perPage,
    ];
}

function renderPagination(array $p, string $baseUrl): string {
    if ($p['total_pages'] <= 1) return '';
    $html = '<div class="pagination">';
    if ($p['current'] > 1)
        $html .= "<a href=\"{$baseUrl}&page=" . ($p['current']-1) . "\" class=\"pg-btn\">‹</a>";
    for ($i = 1; $i <= $p['total_pages']; $i++) {
        $active = $i === $p['current'] ? ' active' : '';
        $html .= "<a href=\"{$baseUrl}&page={$i}\" class=\"pg-btn{$active}\">{$i}</a>";
    }
    if ($p['current'] < $p['total_pages'])
        $html .= "<a href=\"{$baseUrl}&page=" . ($p['current']+1) . "\" class=\"pg-btn\">›</a>";
    $html .= '</div>';
    return $html;
}